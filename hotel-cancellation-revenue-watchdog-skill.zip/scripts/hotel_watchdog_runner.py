#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
hotel_watchdog_runner.py — 酒店预订取消率预警与收益巡检固化脚本

实现 SKILL.md 契约的完整管线：
字段校验 → 数据质量审计 → 清洗留痕 → 派生字段 → 日期窗口
→ 指标计算（分子/分母/样本量标记）→ 交叉风险分析 → 风险表
→ 深度诊断 → 图表 → 中文主报告 → summary.json → 完整交付包。

用法：
  python hotel_watchdog_runner.py --data-file hotel_bookings.csv \
      --output-dir output --dimensions all --top-n 10

边界：本脚本只做分析与建议；不执行处罚、下架、调价、资源重分配等业务动作。
reservation_status 为数据泄漏字段，仅用于数据质量一致性审计，不进入预警输入。
"""
import argparse
import json
import os
import shutil
import sys
import tempfile
import zipfile
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

SKILL_NAME = "hotel-cancellation-revenue-watchdog"
NULL_STRINGS = ["NULL", "null", "None", "", "nan", "NaN", "N/A", "NA"]

DEFAULT_FIELDS = {
    "hotel": "hotel", "is_canceled": "is_canceled", "adr": "adr",
    "lead_time": "lead_time", "market_segment": "market_segment",
    "distribution_channel": "distribution_channel", "deposit_type": "deposit_type",
    "customer_type": "customer_type", "reserved_room_type": "reserved_room_type",
    "assigned_room_type": "assigned_room_type",
    "required_car_parking_spaces": "required_car_parking_spaces",
    "total_of_special_requests": "total_of_special_requests",
    "adults": "adults", "children": "children", "babies": "babies",
    "stays_in_weekend_nights": "stays_in_weekend_nights",
    "stays_in_week_nights": "stays_in_week_nights",
    "arrival_date_year": "arrival_date_year",
    "arrival_date_month": "arrival_date_month",
    "arrival_date_day_of_month": "arrival_date_day_of_month",
    "reservation_status": "reservation_status",
    "reservation_status_date": "reservation_status_date",
    "country": "country", "agent": "agent", "company": "company",
}

DEFAULT_THRESHOLDS = {
    "min_sample_size": 30,
    "min_sample_for_risk": 100,
    "cancellation_rate_alert": 0.40,
    "cancellation_rate_critical": 0.60,
    "non_refund_cancel_alert": 0.90,
    "room_change_rate_alert": 0.15,
    "adr_extreme_percentile": 99,
}

REQUIRED_FIELDS = [
    "hotel", "is_canceled", "adr", "lead_time", "market_segment",
    "distribution_channel", "deposit_type", "customer_type",
    "reserved_room_type", "assigned_room_type",
    "arrival_date_year", "arrival_date_month", "arrival_date_day_of_month",
]

FIELD_ALIASES = {
    "hotel": ["hotel", "hotel_type", "酒店", "酒店类型"],
    "is_canceled": ["is_canceled", "iscanceled", "is_cancelled", "canceled", "是否取消", "取消标记"],
    "adr": ["adr", "average_daily_rate", "平均每日房价"],
    "lead_time": ["lead_time", "leadtime", "提前期", "预订提前期"],
    "market_segment": ["market_segment", "marketsegment", "市场细分"],
    "distribution_channel": ["distribution_channel", "channel", "销售渠道"],
    "deposit_type": ["deposit_type", "deposit", "押金类型", "押金政策"],
    "customer_type": ["customer_type", "customertype", "客户类型"],
    "reserved_room_type": ["reserved_room_type", "预订房型"],
    "assigned_room_type": ["assigned_room_type", "实际分配房型"],
    "arrival_date_year": ["arrival_date_year", "arrival_year", "到店年"],
    "arrival_date_month": ["arrival_date_month", "arrival_month", "到店月"],
    "arrival_date_day_of_month": ["arrival_date_day_of_month", "arrival_day", "到店日"],
}

MONTHS_EN = {
    "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
    "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12,
    "jan": 1, "feb": 2, "mar": 3, "apr": 4, "jun": 6, "jul": 7, "aug": 8,
    "sep": 9, "sept": 9, "oct": 10, "nov": 11, "dec": 12,
}
MONTHS_ZH = {"1月": 1, "2月": 2, "3月": 3, "4月": 4, "5月": 5, "6月": 6,
             "7月": 7, "8月": 8, "9月": 9, "10月": 10, "11月": 11, "12月": 12}


# ---------------------------------------------------------------- 工具函数

def parse_month(v):
    s = str(v).strip()
    if s.isdigit():
        return int(s)
    low = s.lower()
    if low in MONTHS_EN:
        return MONTHS_EN[low]
    if s in MONTHS_ZH:
        return MONTHS_ZH[s]
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def setup_chinese_font():
    """探测中文字体，返回字体名（找不到返回 None，图表标签退化为英文）。"""
    try:
        from matplotlib import font_manager
        avail = {f.name for f in font_manager.fontManager.ttflist}
        for name in ["Microsoft YaHei", "SimHei", "PingFang SC",
                     "Noto Sans CJK SC", "Source Han Sans SC", "WenQuanYi Micro Hei"]:
            if name in avail:
                plt.rcParams["font.sans-serif"] = [name] + plt.rcParams["font.sans-serif"]
                return name
    except Exception:
        pass
    return None


def sample_flag(n, thr):
    if n >= thr["min_sample_for_risk"]:
        return "充足(>=100)"
    if n >= thr["min_sample_size"]:
        return "中等(30-99)"
    return "小样本(<30)"


def risk_flag(n, rate, thr, deposit_value=None):
    if rate is None:
        return "n/a"
    if deposit_value == "Non Refund" and rate >= thr["non_refund_cancel_alert"]:
        return "重点风险【待人工审核】"
    if n < thr["min_sample_size"]:
        return "仅展示"
    flags = []
    if rate >= thr["cancellation_rate_critical"]:
        flags.append("重点风险")
    elif rate >= thr["cancellation_rate_alert"]:
        flags.append("风险信号")
    if deposit_value == "Non Refund" and rate >= thr["cancellation_rate_alert"]:
        flags.append("建议复核")
    return "、".join(flags) if flags else "正常"


def risk_priority(flag_text):
    order = ["重点风险【待人工审核】", "重点风险", "风险信号", "建议复核", "仅展示", "n/a", "正常"]
    for i, k in enumerate(order):
        if flag_text and k and k in str(flag_text):
            return i
    return len(order)


def fmt_pct(x, digits=2):
    if x is None:
        return "n/a"
    try:
        if np.isnan(x):
            return "n/a"
    except (TypeError, ValueError):
        pass
    return f"{x * 100:.{digits}f}%"


def safe_rate(num, den):
    return None if not den else num / den


# ---------------------------------------------------------------- 数据加载

def load_data(path):
    """读取 CSV（支持 zip 自动解压）；返回 (DataFrame, encoding, 实际路径)。"""
    real_path = path
    if str(path).lower().endswith(".zip"):
        tmp_dir = tempfile.mkdtemp(prefix="hotel_watchdog_")
        with zipfile.ZipFile(path) as zf:
            csvs = [n for n in zf.namelist() if n.lower().endswith(".csv")]
            if not csvs:
                raise FileNotFoundError(f"压缩包内未找到 CSV：{path}")
            target = sorted(csvs)[0]
            zf.extract(target, tmp_dir)
            real_path = os.path.join(tmp_dir, target)
    used_enc, last_err = None, None
    for enc in ["utf-8-sig", "utf-8", "gbk", "latin-1"]:
        try:
            df = pd.read_csv(real_path, encoding=enc)
            used_enc = enc
            break
        except (UnicodeDecodeError, UnicodeError) as e:
            last_err = e
            continue
    if used_enc is None:
        raise IOError(f"无法读取文件（编码探测失败）：{path}；最后错误：{last_err}")
    return df, used_enc, real_path


def map_fields(df):
    """字段映射：精确名 → 别名推断。返回 (map, 推断记录, 缺失必需字段)。"""
    lower_map = {str(c).strip().lower(): str(c).strip() for c in df.columns}
    fmap, inferred, missing = {}, [], []
    for role, default_name in DEFAULT_FIELDS.items():
        if default_name in df.columns:
            fmap[role] = default_name
            continue
        hit = lower_map.get(default_name.lower())
        if hit:
            fmap[role] = hit
            inferred.append({"role": role, "actual": hit, "via": "忽略大小写"})
            continue
        for alias in FIELD_ALIASES.get(role, []):
            hit = lower_map.get(alias.lower())
            if hit:
                fmap[role] = hit
                inferred.append({"role": role, "actual": hit, "via": f"别名推断({alias})"})
                break
        if role not in fmap and role in REQUIRED_FIELDS:
            missing.append(role)
    return fmap, inferred, missing


def load_config(path):
    with open(path, "r", encoding="utf-8") as f:
        text = f.read()
    if path.endswith(".json"):
        return json.loads(text)
    try:
        import yaml
        return yaml.safe_load(text)
    except ImportError:
        raise RuntimeError("YAML 配置需要 pyyaml；或改用 JSON 配置文件")


# ---------------------------------------------------------------- 指标计算

def rate_by_dim(w, col, label, thr, top=None):
    """按维度计算取消率表（分子/分母/样本量标记/风险标记）。"""
    ic = "__is_canceled__"
    g = w.groupby(col, dropna=False).agg(
        总单量=(ic, "size"), 取消量=(ic, "sum")).reset_index()
    g["取消率"] = (g["取消量"] / g["总单量"]).round(4)
    g["样本量标记"] = g["总单量"].map(lambda n: sample_flag(int(n), thr))
    g["风险标记"] = g.apply(
        lambda r: risk_flag(int(r["总单量"]),
                            float(r["取消率"]) if pd.notna(r["取消率"]) else None, thr,
                            deposit_value=str(r[col]).strip() if label == "deposit_type" else None),
        axis=1)
    g = g.rename(columns={col: "维度取值"})
    g.insert(0, "维度", label)
    g = g.sort_values(["取消率", "总单量"], ascending=[False, False])
    if top:
        g = g.head(top)
    return g[["维度", "维度取值", "总单量", "取消量", "取消率", "样本量标记", "风险标记"]]


def dimension_risk_rows(w, col, label, thr, top=None):
    """构建风险表行：维度、维度取值、总单量、取消量、取消率、ADR中位数、ADR_P95、
    房型变更率、停车位需求率、特殊请求率、风险标记、样本量标记。"""
    rows = []
    ic, adr, room, park, spec = ("__is_canceled__", "__adr__", "__room_changed__",
                                  "__parking__", "__special_req__")
    for dim_val, x in w.groupby(col, dropna=False):
        n, c = len(x), int(x[ic].sum())
        rate = safe_rate(c, n)
        dep = str(dim_val).strip() if label == "deposit_type" else None
        row = {"维度": label, "维度取值": dim_val, "总单量": n, "取消量": c,
               "取消率": round(rate, 4) if rate is not None else None}
        if adr in x and x[adr].notna().any():
            s = x[adr].dropna()
            row["ADR中位数"] = round(float(s.median()), 2)
            row["ADR_P95"] = round(float(s.quantile(0.95)), 2)
        else:
            row["ADR中位数"] = None
            row["ADR_P95"] = None
        row["房型变更率"] = round(safe_rate(int(x[room].sum()), n), 4) if room in x else None
        row["停车位需求率"] = round(safe_rate(int(x[park].sum()), n), 4) if park in x else None
        row["特殊请求率"] = round(safe_rate(int(x[spec].sum()), n), 4) if spec in x else None
        row["风险标记"] = risk_flag(n, rate, thr, deposit_value=dep)
        row["样本量标记"] = sample_flag(n, thr)
        rows.append(row)
    rows.sort(key=lambda r: (risk_priority(r["风险标记"]),
                             -(r["取消率"] if r["取消率"] is not None else -1),
                             -(r["ADR中位数"] if r["ADR中位数"] is not None else -1),
                             -r["总单量"]))
    if top:
        rows = rows[:top]
    return rows


def cross_table(w, cols, gname, thr):
    if not all(c in w.columns for c in cols):
        return None
    ic = "__is_canceled__"
    g = w.groupby(cols, dropna=False).agg(
        总单量=(ic, "size"), 取消量=(ic, "sum")).reset_index()
    g["取消率"] = (g["取消量"] / g["总单量"]).round(4)
    g["样本量标记"] = g["总单量"].map(lambda n: sample_flag(int(n), thr))

    def _flag(r):
        dep = None
        for c in cols:
            if "deposit" in str(c).lower() and str(r[c]).strip() == "Non Refund":
                dep = "Non Refund"
        return risk_flag(int(r["总单量"]),
                          float(r["取消率"]) if pd.notna(r["取消率"]) else None, thr,
                          deposit_value=dep)

    g["风险标记"] = g.apply(_flag, axis=1)
    g["风险优先级"] = g["风险标记"].map(risk_priority)
    g["分析组"] = gname
    g["组合"] = g[cols].astype(str).agg(" × ".join, axis=1)
    out = g[["分析组", "组合", "总单量", "取消量", "取消率", "样本量标记", "风险标记", "风险优先级"]]
    return out.sort_values(["风险优先级", "取消率"], ascending=[True, False])


def compute_kpi(w, fmap, cancel_ok, adr_ok, room_ok):
    kpi = {}
    if cancel_ok and len(w):
        ic = w["__is_canceled__"]
        kpi["overall_cancellation"] = {"numerator": int(ic.sum()), "denominator": len(ic),
                                       "rate": safe_rate(int(ic.sum()), len(ic))}
        hotels = list(pd.unique(w[fmap["hotel"]].dropna())) if "hotel" in fmap else []
        picked = [h for h in hotels if "City" in str(h) or "Resort" in str(h)] or hotels[:2]
        for h in picked:
            sub = w[w[fmap["hotel"]] == h]
            key = "cancellation_" + str(h).replace(" ", "_")
            kpi[key] = {"numerator": int(sub["__is_canceled__"].sum()), "denominator": len(sub),
                        "rate": safe_rate(int(sub["__is_canceled__"].sum()), len(sub))}
    if adr_ok and "__adr__" in w and w["__adr__"].notna().any():
        kpi["adr_median"] = float(w["__adr__"].median())
    if room_ok and "__room_changed__" in w:
        kpi["room_change_rate"] = {"numerator": int(w["__room_changed__"].sum()),
                                   "denominator": len(w),
                                   "rate": safe_rate(int(w["__room_changed__"].sum()), len(w))}
    return kpi


# ---------------------------------------------------------------- 主流程

def main():
    args = parse_args()
    thr = dict(DEFAULT_THRESHOLDS)
    overrides = []
    fmap_cfg = {}

    if args.config:
        cfg = load_config(args.config)
        for k, v in (cfg.get("thresholds") or {}).items():
            if k in thr:
                overrides.append({"key": k, "source": f"config:{args.config}",
                                  "old": thr[k], "new": v})
                thr[k] = type(thr[k])(v)
        fmap_cfg = cfg.get("fields") or {}

    for kv in args.set_ or []:
        if "=" not in kv:
            print(f"[警告] 忽略非法阈值覆盖（应为 KEY=VALUE）：{kv}")
            continue
        k, v = kv.split("=", 1)
        if k not in thr:
            print(f"[警告] 未知阈值键，忽略：{k}")
            continue
        overrides.append({"key": k, "source": "命令行 --set", "old": thr[k], "new": v})
        thr[k] = type(thr[k])(v)

    out_root = args.output_dir or os.path.join(
        os.path.dirname(os.path.abspath(args.data_file)), "output")
    for sub in ["clean-data", "quality", "risk-tables", "detail-tables",
                "deep-diagnosis", "statistics", "charts", "PBL交付物"]:
        os.makedirs(os.path.join(out_root, sub), exist_ok=True)

    quality_rows, cleaning_rows = [], []
    blockers, warnings, degraded, manual_review = [], [], [], []

    def q(item, status, value, note=""):
        quality_rows.append({"检查项": item, "状态": status, "数值/结果": value, "说明": note})

    # ---- 1. 读取数据 ----
    print(f"[1/10] 读取数据：{args.data_file}")
    df, encoding, real_path = load_data(args.data_file)
    n_rows, n_cols = len(df), len(df.columns)
    q("文件读取", "通过", f"{n_rows} 行 × {n_cols} 列", f"编码 {encoding}")
    print(f"      {n_rows:,} 行 × {n_cols} 列，编码 {encoding}")

    # ---- 字段映射 ----
    fmap, inferred, missing_required = map_fields(df)
    for role, actual in fmap_cfg.items():
        if actual in df.columns and role in DEFAULT_FIELDS:
            fmap[role] = actual
            inferred.append({"role": role, "actual": actual, "via": "config 指定"})
    for it in inferred:
        q("字段映射推断", "通过", f"{it['role']} -> {it['actual']}", it["via"])
    has = lambda role: role in fmap  # noqa: E731

    if missing_required:
        detail = "、".join(missing_required)
        q("必需字段齐全性", "阻断", f"缺失 {len(missing_required)} 项", detail)
        blockers.append(f"缺失必需字段：{detail}（阻断对应分析）")
        for role in missing_required:
            if role in ("hotel", "is_canceled"):
                degraded.append(f"{role} 缺失：阻断核心分组与取消率分析")
            elif role == "adr":
                degraded.append("adr 缺失：降级收益巡检")
            elif role in ("reserved_room_type", "assigned_room_type"):
                degraded.append(f"{role} 缺失：降级资源匹配巡检")
            elif str(role).startswith("arrival"):
                degraded.append("到店日期字段缺失：阻断日期窗口与趋势分析")
            else:
                degraded.append(f"{role} 缺失：降级对应维度分析")
    else:
        q("必需字段齐全性", "通过", f"{len(REQUIRED_FIELDS)}/{len(REQUIRED_FIELDS)}", "全部必需字段就位")

    # ---- 2. 数据质量校验 ----
    print("[2/10] 数据质量校验")
    df = df.replace(NULL_STRINGS, np.nan)
    for role in ("children", "adults", "babies", "required_car_parking_spaces",
                 "total_of_special_requests", "stays_in_weekend_nights",
                 "stays_in_week_nights", "adr", "lead_time",
                 "arrival_date_year", "arrival_date_day_of_month"):
        if has(role):
            df[fmap[role]] = pd.to_numeric(df[fmap[role]], errors="coerce")
    if has("is_canceled"):
        df[fmap["is_canceled"]] = pd.to_numeric(df[fmap["is_canceled"]], errors="coerce")

    is_canceled_ok = False
    if has("is_canceled"):
        col = fmap["is_canceled"]
        n_bad = int((~df[col].isin([0, 1])).sum())
        if n_bad > 0:
            q("is_canceled 取值合法性", "阻断", f"{n_bad} 行非法",
              f"示例：{df.loc[~df[col].isin([0, 1]), col].unique()[:5].tolist()}")
            blockers.append(f"is_canceled 存在 {n_bad} 行非法取值，在计算取消率之前停止")
        else:
            q("is_canceled 取值合法性", "通过", "仅含 0/1", "")
            n_cancel = int((df[col] == 1).sum())
            if n_cancel == 0:
                q("取消记录存在性", "阻断", "0 条取消", "无取消记录，阻断取消率分析")
                blockers.append("数据中无任何取消记录，阻断取消率分析")
            else:
                q("取消记录存在性", "通过", f"{n_cancel} 条取消", f"占 {n_cancel / n_rows:.2%}")
                is_canceled_ok = True
    if has("is_canceled") and has("hotel"):
        cancel_ok = is_canceled_ok
    else:
        cancel_ok = False

    if has("arrival_date_month"):
        df["_month_num"] = df[fmap["arrival_date_month"]].map(parse_month)
    date_ok = False
    if has("arrival_date_year") and has("arrival_date_month") and has("arrival_date_day_of_month"):
        df["_arrival_date"] = pd.to_datetime(
            dict(year=df[fmap["arrival_date_year"]],
                 month=df["_month_num"],
                 day=df[fmap["arrival_date_day_of_month"]]),
            errors="coerce")
        n_bad_date = int(df["_arrival_date"].isna().sum())
        if n_bad_date == n_rows:
            q("到店日期可构造性", "阻断", "全部失败", "日期窗口与趋势分析阻断")
            blockers.append("到店日期无法构造：阻断日期窗口与趋势分析")
        elif n_bad_date > 0:
            q("到店日期可构造性", "警告", f"{n_bad_date} 行无效", "无效日期行排除出日期窗口分析")
            warnings.append(f"{n_bad_date} 行到店日期无法构造")
            date_ok = True
        else:
            q("到店日期可构造性", "通过", "0 行无效", "")
            date_ok = True

    n_dup_extra = int(df.duplicated().sum())
    n_dup_group = int(df.duplicated(keep=False).sum())
    dup_ratio = safe_rate(n_dup_group, n_rows)
    q("重复行统计", "警告" if n_dup_extra > 0 else "通过",
      f"多余 {n_dup_extra} 行；重复组 {n_dup_group} 行",
      "默认 report_only，未经用户明确指示不得删除")
    if n_dup_extra > 0:
        warnings.append(f"存在 {n_dup_extra:,} 条多余重复行（report_only，未删除）")
    if dup_ratio is not None and dup_ratio > 0.20:
        manual_review.append({
            "事项": "无 booking_id 且重复行占比超过 20%",
            "证据": f"重复组 {n_dup_group:,}/{n_rows:,} 行（{fmt_pct(dup_ratio)}），数据无唯一订单 ID",
            "建议": "确认重复属于口径还是采集问题后再决定是否去重【待人工审核】"})

    for role in ("company", "agent", "country", "children"):
        if has(role):
            n_miss = int(df[fmap[role]].isna().sum())
            rate = safe_rate(n_miss, n_rows)
            status = "警告" if (rate or 0) > 0.10 else ("通过" if n_miss == 0 else "提示")
            q(f"{role} 缺失统计", status, f"{n_miss} 行", f"缺失率 {fmt_pct(rate)}")

    adr_p95 = adr_p99 = None
    adr_ok = False
    if has("adr"):
        s = df[fmap["adr"]].dropna()
        if len(s):
            adr_p95 = float(s.quantile(0.95))
            adr_p99 = float(s.quantile(thr["adr_extreme_percentile"] / 100.0))
            n_le0 = int((s <= 0).sum())
            n_gt_p99 = int((s > adr_p99).sum())
            adr_share_bad = n_le0 / len(s)
            q("ADR 分布", "警告" if adr_share_bad > 0.05 else "提示",
              f"min={s.min():.2f}, max={s.max():.2f}, 均值={s.mean():.2f}, 中位数={s.median():.2f}",
              f"P95={adr_p95:.2f}, P99={adr_p99:.2f}, adr<=0 共 {n_le0} 条, adr>P99 共 {n_gt_p99} 条")
            if adr_share_bad > 0.05:
                blockers.append(f"adr<=0 占比 {adr_share_bad:.2%} 超过 5%：阻断收益判断，保留取消率分析")
                degraded.append("ADR 收益判断被阻断（adr<=0 占比超 5%）")
            else:
                adr_ok = True
        else:
            degraded.append("adr 全列无效：降级收益巡检")
    else:
        degraded.append("adr 缺失：降级收益巡检")

    if has("reservation_status") and has("is_canceled"):
        rs = df[fmap["reservation_status"]].astype(str)
        inconsistent = int(((rs == "Canceled") != (df[fmap["is_canceled"]] == 1)).sum())
        q("reservation_status 与 is_canceled 一致性", "提示" if inconsistent else "通过",
          f"{inconsistent} 行不一致", "仅用于数据质量审计，该字段不作为预警输入")

    if args.strict and warnings:
        blockers.extend([f"[strict] 质量告警升级为阻断：{w}" for w in warnings])

    pd.DataFrame(quality_rows).to_csv(
        os.path.join(out_root, "quality", "data_quality.csv"),
        index=False, encoding="utf-8-sig")
    print(f"      质量检查 {len(quality_rows)} 项（阻断 {len(blockers)}，警告 {len(warnings)}）")

    # ---- 3. 清洗（带审计留痕） ----
    print("[3/10] 带审计留痕的清洗")
    clean = df.copy()

    def log(table, field, action, rows, reason, fill="", rng=""):
        cleaning_rows.append({"表": table, "字段": field, "动作": action, "行数": rows,
                              "原因": reason, "填充值": fill, "取值范围": rng})

    log("bookings", "(整表)", "重复行 report_only", n_dup_extra,
        "无可靠 booking_id，默认仅报告不删除", "", f"重复组 {n_dup_group} 行")

    if has("children"):
        n_miss = int(clean[fmap["children"]].isna().sum())
        if n_miss:
            clean[fmap["children"]] = clean[fmap["children"]].fillna(0)
            log("bookings", fmap["children"], "缺失填充 0", n_miss,
                "children 缺失（影响 total_guests）", "0")
    if has("country"):
        n_miss = int(clean[fmap["country"]].isna().sum())
        if n_miss:
            clean[fmap["country"]] = clean[fmap["country"]].fillna("Unknown")
            log("bookings", fmap["country"], "缺失填充 Unknown", n_miss,
                "国家维度统计需完整覆盖", "Unknown")
    for role, flag_name in (("agent", "has_agent"), ("company", "has_company")):
        if has(role):
            clean[flag_name] = clean[fmap[role]].notna().astype(int)
            n_miss = int(clean[fmap[role]].isna().sum())
            log("bookings", fmap[role], f"构造存在标记 {flag_name}", len(clean),
                f"缺失 {n_miss} 行（{fmt_pct(safe_rate(n_miss, n_rows))}），不作为主分析字段")
    if has("adr"):
        log("bookings", fmap["adr"], "转数值并标记异常", len(clean),
            "adr<=0 或 adr>P99 标记为异常，不删除", "", f"P99={adr_p99}")
    for col in clean.columns:
        if clean[col].dtype == object:
            stripped = clean[col].apply(lambda x: x.strip() if isinstance(x, str) else x)
            n_trim = int((stripped.fillna("§") != clean[col].fillna("§")).sum())
            if n_trim:
                clean[col] = stripped
                log("bookings", col, "去除首尾空白", n_trim, "文本标准化，不改变业务含义")

    pd.DataFrame(cleaning_rows).to_csv(
        os.path.join(out_root, "quality", "cleaning_log.csv"),
        index=False, encoding="utf-8-sig")

    # ---- 4. 派生字段 ----
    print("[4/10] 构造派生字段")
    d = clean.copy()
    d["total_guests"] = sum(d[fmap[r]].fillna(0) for r in ("adults", "children", "babies") if has(r)) \
        if any(has(r) for r in ("adults", "children", "babies")) else 0
    d["total_stays"] = sum(d[fmap[r]].fillna(0) for r in ("stays_in_weekend_nights", "stays_in_week_nights") if has(r)) \
        if any(has(r) for r in ("stays_in_weekend_nights", "stays_in_week_nights")) else 0
    if has("reserved_room_type") and has("assigned_room_type"):
        d["is_room_changed"] = (d[fmap["reserved_room_type"]].astype(str) !=
                                 d[fmap["assigned_room_type"]].astype(str)).astype(int)
    else:
        d["is_room_changed"] = np.nan
    if has("lead_time"):
        d["lead_time_bucket"] = pd.cut(d[fmap["lead_time"]].fillna(-1),
                                       bins=[-2, 7, 30, 90, 180, np.inf],
                                       labels=["0-7", "8-30", "31-90", "91-180", "180+"]
                                       ).astype(str).replace("nan", "n/a")
    else:
        d["lead_time_bucket"] = "n/a"
    if has("adr"):
        d["adr_bucket"] = pd.cut(d[fmap["adr"]],
                                 bins=[-np.inf, 0, 50, 100, 150, 200, np.inf],
                                 labels=["<=0", "0-50", "51-100", "101-150", "151-200", "200+"]
                                 ).astype(str).replace("nan", "n/a")
        d["adr_anomaly_flag"] = ((d[fmap["adr"]] <= 0) |
                                 (d[fmap["adr"]] > adr_p99)).fillna(False).astype(int)
    else:
        d["adr_bucket"], d["adr_anomaly_flag"] = "n/a", np.nan
    d["arrival_date"] = d.get("_arrival_date", pd.NaT)

    n_g0 = int((d["total_guests"] == 0).sum())
    n_s0 = int((d["total_stays"] == 0).sum())
    n_rc = int((d["is_room_changed"] == 1).sum()) if d["is_room_changed"].notna().any() else 0
    n_adr_a = int((d["adr_anomaly_flag"] == 1).sum()) if d["adr_anomaly_flag"].notna().any() else 0
    for item, n in (("total_guests=0", n_g0), ("total_stays=0", n_s0),
                    ("is_room_changed=1", n_rc), ("adr_anomaly_flag=1", n_adr_a)):
        q(f"标记统计 {item}", "提示", f"{n} 行", f"占比 {fmt_pct(safe_rate(n, n_rows))}")

    clean_out = clean.drop(columns=[c for c in ("_month_num", "_arrival_date") if c in clean.columns])
    clean_out.to_csv(os.path.join(out_root, "clean-data", "bookings_clean.csv"),
                     index=False, encoding="utf-8-sig")
    d_out = d.drop(columns=[c for c in ("_month_num", "_arrival_date") if c in d.columns])
    d_out.to_csv(os.path.join(out_root, "clean-data", "bookings_derived.csv"),
                 index=False, encoding="utf-8-sig")

    # ---- 5. 日期窗口 + 内部标准列 ----
    print("[5/10] 应用日期窗口")
    d_min = d["arrival_date"].min() if date_ok else None
    d_max = d["arrival_date"].max() if date_ok else None
    w = d.copy()
    excluded = 0
    if date_ok:
        if args.start:
            mask = w["arrival_date"] >= pd.Timestamp(args.start)
            excluded += int((~mask).sum())
            w = w[mask]
        if args.end:
            mask = w["arrival_date"] <= pd.Timestamp(args.end)
            excluded += int((~mask).sum())
            w = w[mask]
        if 0 < len(w) < 1000:
            warnings.append(f"日期窗口内仅 {len(w)} 行，比率类结论将标记为小样本")
        q("日期窗口", "提示" if (args.start or args.end) else "通过",
          f"原始范围 {d_min} ~ {d_max}",
          f"窗口 [{args.start or d_min}] ~ [{args.end or d_max}]（end 含当天），"
          f"保留 {len(w)} 行，排除 {excluded} 行")
    else:
        q("日期窗口", "阻断", "n/a", "到店日期不可用，未应用窗口")
    print(f"      窗口内 {len(w):,} 行（排除 {excluded:,} 行）")

    # 内部标准列（屏蔽用户字段名差异）
    if cancel_ok:
        w["__is_canceled__"] = w[fmap["is_canceled"]].astype(int)
    if adr_ok:
        w["__adr__"] = w[fmap["adr"]]
    room_ok = d["is_room_changed"].notna().any() and len(w) > 0
    if room_ok:
        w["__room_changed__"] = w["is_room_changed"].fillna(0).astype(int)
    if has("required_car_parking_spaces"):
        w["__parking__"] = (w[fmap["required_car_parking_spaces"]].fillna(0) > 0).astype(int)
    if has("total_of_special_requests"):
        w["__special_req__"] = (w[fmap["total_of_special_requests"]].fillna(0) > 0).astype(int)
    if date_ok:
        w["__ym__"] = w["arrival_date"].dt.strftime("%Y-%m")

    # ---- 6. 核心指标 ----
    print("[6/10] 计算核心指标")
    rate_dims = []
    for role in ("hotel", "market_segment", "distribution_channel",
                 "deposit_type", "customer_type"):
        if has(role):
            rate_dims.append((role, fmap[role], role))
    if date_ok and "__ym__" in w:
        rate_dims.append(("month", "__ym__", "arrival_date_month"))
    if has("country"):
        rate_dims.append(("country", fmap["country"], "country"))

    rate_tables = {}
    if cancel_ok:
        for key, col, label in rate_dims:
            rate_tables[key] = rate_by_dim(w, col, label, thr,
                                           top=15 if key == "country" else None)
        file_map = {"hotel": "cancellation_by_hotel.csv",
                    "market_segment": "cancellation_by_market_segment.csv",
                    "distribution_channel": "cancellation_by_channel.csv",
                    "deposit_type": "cancellation_by_deposit.csv",
                    "customer_type": "cancellation_by_customer_type.csv"}
        for key, fname in file_map.items():
            if key in rate_tables:
                rate_tables[key].to_csv(os.path.join(out_root, "risk-tables", fname),
                                        index=False, encoding="utf-8-sig")
        # 模板契约：合并取消率汇总单表 cancellation_summary.csv
        frames = [rate_tables[key] for key in file_map if key in rate_tables]
        if frames:
            pd.concat(frames, ignore_index=True).to_csv(
                os.path.join(out_root, "risk-tables", "cancellation_summary.csv"),
                index=False, encoding="utf-8-sig")

    if adr_ok:
        adr_rows = []
        for role in ("hotel", "market_segment", "distribution_channel", "customer_type"):
            if has(role):
                for dim_val, serie in w.groupby(fmap[role])["__adr__"]:
                    serie = serie.dropna()
                    if not len(serie):
                        continue
                    adr_rows.append({
                        "维度": role, "维度取值": dim_val, "样本量": int(serie.size),
                        "ADR均值": round(float(serie.mean()), 2),
                        "ADR中位数": round(float(serie.median()), 2),
                        "ADR_P95": round(float(serie.quantile(0.95)), 2),
                        "ADR_P99": round(float(serie.quantile(thr["adr_extreme_percentile"] / 100.0)), 2),
                        "adr<=0数量": int((serie <= 0).sum()),
                        "adr>P99数量": int((serie > adr_p99).sum()),
                        "样本量标记": sample_flag(int(serie.size), thr)})
        pd.DataFrame(adr_rows).to_csv(
            os.path.join(out_root, "risk-tables", "adr_by_dimensions.csv"),
            index=False, encoding="utf-8-sig")

    if room_ok and date_ok and "__ym__" in w:
        res = w.groupby([fmap["hotel"], "__ym__"], dropna=False).agg(
            总单量=("__is_canceled__", "size"),
            取消量=("__is_canceled__", "sum"),
            房型变更量=("__room_changed__", "sum"),
            停车位需求量=("__parking__", "sum") if has("required_car_parking_spaces")
            else ("__is_canceled__", "size"),
            特殊请求量=("__special_req__", "sum") if has("total_of_special_requests")
            else ("__is_canceled__", "size"),
        ).reset_index()
        res["房型变更率(分子/分母)"] = res.apply(
            lambda r: f"{r['房型变更量']}/{r['总单量']}", axis=1)
        res["房型变更率"] = (res["房型变更量"] / res["总单量"]).round(4)
        res["停车位需求率"] = (res["停车位需求量"] / res["总单量"]).round(4)
        res["特殊请求率"] = (res["特殊请求量"] / res["总单量"]).round(4)
        res = res.rename(columns={fmap["hotel"]: "hotel", "__ym__": "月份"})
        res.to_csv(os.path.join(out_root, "detail-tables", "room_resource_check.csv"),
                   index=False, encoding="utf-8-sig")

    # ---- 7. 交叉分析 ----
    print("[7/10] 交叉分析")
    cross_all = []
    if cancel_ok:
        groups = []
        if has("hotel") and has("market_segment"):
            groups.append(("hotel×market_segment", [fmap["hotel"], fmap["market_segment"]]))
        if has("deposit_type") and has("customer_type"):
            groups.append(("deposit_type×customer_type",
                           [fmap["deposit_type"], fmap["customer_type"]]))
        if has("lead_time"):
            groups.append(("lead_time_bucket×is_canceled", ["lead_time_bucket"]))
        if has("adr"):
            groups.append(("adr_bucket×is_canceled", ["adr_bucket"]))
        if has("total_of_special_requests"):
            groups.append(("total_of_special_requests×is_canceled",
                           [fmap["total_of_special_requests"]]))
        if has("distribution_channel") and has("deposit_type"):
            groups.append(("distribution_channel×deposit_type",
                           [fmap["distribution_channel"], fmap["deposit_type"]]))
        if args.cross_groups:
            wanted = [g.strip() for g in args.cross_groups.split(",")]
            filtered = [g for g in groups
                        if any(wd in g[0] or any(wd in str(c) for c in g[1]) for wd in wanted)]
            groups = filtered or groups[:2]
        for gname, cols in groups[:6]:
            t = cross_table(w, cols, gname, thr)
            if t is not None:
                cross_all.append(t)
        if cross_all:
            cross_df = pd.concat(cross_all, ignore_index=True)
            cross_df.drop(columns=["风险优先级"]).to_csv(
                os.path.join(out_root, "risk-tables", "cross_analysis_results.csv"),
                index=False, encoding="utf-8-sig")
            risky = cross_df[cross_df["风险标记"].str.contains("风险|复核", na=False)] \
                .sort_values(["风险优先级", "取消率"], ascending=[True, False]).head(args.top_n)
            risky.drop(columns=["风险优先级"]).to_csv(
                os.path.join(out_root, "detail-tables", "risk_combinations.csv"),
                index=False, encoding="utf-8-sig")
            for _, r in risky.iterrows():
                if "待人工审核" in str(r["风险标记"]):
                    manual_review.append({
                        "事项": f"{r['分析组']} 组合「{r['组合']}」取消率 "
                                f"{fmt_pct(float(r['取消率']) if pd.notna(r['取消率']) else None)}",
                        "证据": f"取消 {r['取消量']}/{r['总单量']}（{r['样本量标记']}）；"
                                f"风险标记：{r['风险标记']}",
                        "建议": "疑似口径或业务定义问题，需人工确认【待人工审核】"})

    # ---- 8. 风险表 ----
    print("[8/10] 构建风险表")
    risk_df = pd.DataFrame()
    if cancel_ok:
        rows = []
        for key, col, label in rate_dims:
            rows.extend(dimension_risk_rows(w, col, label, thr,
                                            top=15 if key == "country" else None))
        if rows:
            risk_df = pd.DataFrame(rows)
            risk_df.to_csv(os.path.join(out_root, "risk-tables", "dimension_risk_table.csv"),
                           index=False, encoding="utf-8-sig")

    if cancel_ok and "deposit_type" in rate_tables:
        dep = rate_tables["deposit_type"]
        nr = dep[dep["维度取值"].astype(str).str.strip() == "Non Refund"]
        for _, r in nr.iterrows():
            if pd.notna(r["取消率"]) and r["取消率"] >= thr["non_refund_cancel_alert"]:
                manual_review.append({
                    "事项": f"Non Refund 押金类型取消率 {fmt_pct(r['取消率'])}",
                    "证据": f"取消 {r['取消量']}/{r['总单量']}（{r['样本量标记']}）",
                    "建议": "可能是业务定义或状态口径问题，不得直接下押金策略失败结论【待人工审核】"})
    if cancel_ok:
        small = []
        for key, t in rate_tables.items():
            s = t[(t["总单量"] < thr["min_sample_size"]) &
                  (t["取消率"] >= thr["cancellation_rate_alert"])]
            for _, r in s.head(6).iterrows():
                small.append(f"{r['维度']}={r['维度取值']}（取消 {r['取消量']}/{r['总单量']}）")
        if small:
            manual_review.append({"事项": "小样本组出现高取消率",
                                  "证据": "；".join(small[:8]),
                                  "建议": "小样本不足以支撑结论，仅提示观察【待人工审核】"})
    if room_ok:
        overall_rc = safe_rate(n_rc, n_rows)
        if overall_rc is not None and overall_rc >= thr["room_change_rate_alert"]:
            manual_review.append({
                "事项": f"整体房型变更率 {fmt_pct(overall_rc)} 达到阈值 "
                        f"{fmt_pct(thr['room_change_rate_alert'])}",
                "证据": f"is_room_changed=1 共 {n_rc:,}/{n_rows:,} 行",
                "建议": "涉及实际运营策略调整，需人工确认【待人工审核】"})

    # ---- 9. 深度诊断 ----
    print("[9/10] 深度诊断")
    deep_ok = date_ok and cancel_ok and len(w) >= 5000
    if deep_ok:
        trend = w.groupby("__ym__").agg(
            总单量=("__is_canceled__", "size"),
            取消量=("__is_canceled__", "sum"),
            房型变更量=("__room_changed__", "sum"),
            停车位需求量=("__parking__", "sum") if has("required_car_parking_spaces")
            else ("__is_canceled__", "size"),
            特殊请求量=("__special_req__", "sum") if has("total_of_special_requests")
            else ("__is_canceled__", "size"),
            ADR中位数=("__adr__", "median") if adr_ok else ("__is_canceled__", "size"),
        ).reset_index()
        trend["取消率"] = (trend["取消量"] / trend["总单量"]).round(4)
        trend["房型变更率"] = (trend["房型变更量"] / trend["总单量"]).round(4)
        trend["停车位需求率"] = (trend["停车位需求量"] / trend["总单量"]).round(4)
        trend["特殊请求率"] = (trend["特殊请求量"] / trend["总单量"]).round(4)
        if not adr_ok:
            trend["ADR中位数"] = None
        trend = trend.rename(columns={"__ym__": "年月"})
        trend.to_csv(os.path.join(out_root, "deep-diagnosis", "trend_comparison.csv"),
                     index=False, encoding="utf-8-sig")

        conc_rows = []
        total_cancel = int(w["__is_canceled__"].sum())
        for role in ("hotel", "market_segment", "distribution_channel",
                     "deposit_type", "customer_type"):
            if has(role):
                g = w.groupby(fmap[role]).agg(
                    总单量=("__is_canceled__", "size"),
                    取消量=("__is_canceled__", "sum"))
                g = g[g["总单量"] >= thr["min_sample_for_risk"]]
                for dim_val, r in g.sort_values("取消量", ascending=False).head(10).iterrows():
                    conc_rows.append({
                        "维度": role, "维度取值": dim_val, "总单量": int(r["总单量"]),
                        "取消量": int(r["取消量"]),
                        "取消率": round(r["取消量"] / r["总单量"], 4),
                        "占全部取消量比": round(r["取消量"] / total_cancel, 4)})
        pd.DataFrame(conc_rows).to_csv(
            os.path.join(out_root, "deep-diagnosis", "cancellation_concentration.csv"),
            index=False, encoding="utf-8-sig")

        amp_rows = []
        overall_cancel = safe_rate(total_cancel, len(w))
        if adr_ok and has("hotel") and has("market_segment"):
            g = w.groupby([fmap["hotel"], fmap["market_segment"]]).agg(
                总单量=("__is_canceled__", "size"),
                取消量=("__is_canceled__", "sum"),
                ADR中位数=("__adr__", "median")).reset_index()
            g["取消率"] = (g["取消量"] / g["总单量"]).round(4)
            overall_adr_med = float(w["__adr__"].median())
            hi = g[(g["取消率"] >= thr["cancellation_rate_alert"]) &
                   (g["ADR中位数"] >= overall_adr_med) &
                   (g["总单量"] >= thr["min_sample_for_risk"])]
            for _, r in hi.sort_values("取消率", ascending=False).head(10).iterrows():
                amp_rows.append({
                    "放大器类型": "高取消率+高ADR",
                    "维度组合": f"{r.iloc[0]} × {r.iloc[1]}",
                    "总单量": int(r["总单量"]), "取消量": int(r["取消量"]),
                    "取消率": r["取消率"], "ADR中位数": round(r["ADR中位数"], 2),
                    "参照": f"总体取消率 {fmt_pct(overall_cancel)}，"
                            f"总体 ADR 中位数 {overall_adr_med:.2f}"})
        if has("lead_time"):
            g = w.groupby("lead_time_bucket").agg(
                总单量=("__is_canceled__", "size"), 取消量=("__is_canceled__", "sum"))
            g["取消率"] = (g["取消量"] / g["总单量"]).round(4)
            base = g.loc["0-7", "取消率"] if "0-7" in g.index else None
            for bucket in ("91-180", "180+"):
                if bucket in g.index and base is not None \
                        and g.loc[bucket, "取消率"] >= thr["cancellation_rate_alert"]:
                    amp_rows.append({
                        "放大器类型": "高取消率+长提前期",
                        "维度组合": f"lead_time_bucket={bucket}",
                        "总单量": int(g.loc[bucket, "总单量"]),
                        "取消量": int(g.loc[bucket, "取消量"]),
                        "取消率": g.loc[bucket, "取消率"], "ADR中位数": None,
                        "参照": f"提前期 0-7 天组取消率 {fmt_pct(base)}（仅相关联，非因果）"})
        pd.DataFrame(amp_rows).to_csv(
            os.path.join(out_root, "deep-diagnosis", "risk_amplifiers.csv"),
            index=False, encoding="utf-8-sig")

    if adr_ok:
        anom = w[(w[fmap["adr"]] <= 0) | (w[fmap["adr"]] > adr_p99)]
        out_cols = [fmap.get(k) for k in ("hotel", "market_segment", "customer_type",
                                           "deposit_type", "lead_time", "is_canceled", "adr")
                    if has(k)]
        out_cols = [c for c in out_cols if c in anom.columns]
        anom = anom.assign(异常类型=np.where(anom[fmap["adr"]] <= 0, "adr<=0", "adr>P99"))
        anom[out_cols + ["异常类型"]].head(5000).to_csv(
            os.path.join(out_root, "detail-tables", "adr_anomaly_list.csv"),
            index=False, encoding="utf-8-sig")

    # ---- 9.5 统计显著性分析 ----
    print("[*] 统计显著性分析（卡方 + Cramér's V + 相关 + 逻辑回归）")
    stat_results = run_statistical_analysis(w, out_root, summary_placeholder=None,
                                            thr=thr, fmap=fmap, has=has,
                                            cancel_ok=cancel_ok)

    # ---- 10. 图表 / 报告 / summary / deliverables ----
    print("[10/10] 生成图表与报告")
    font = setup_chinese_font()
    zh_ok = font is not None

    kpi = compute_kpi(w, fmap, cancel_ok, adr_ok, room_ok)
    make_charts(out_root, w, fmap, rate_tables, kpi, thr, zh_ok,
                cancel_ok, adr_ok, room_ok)

    summary = {
        "skill": SKILL_NAME,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "input": {"file": os.path.abspath(args.data_file), "encoding": encoding,
                  "rows": n_rows, "cols": n_cols},
        "field_mapping": fmap,
        "field_inference": inferred,
        "fact_table_role": "预订事实表（一行一订单）",
        "date_range_original": [str(d_min.date()) if d_min is not None else None,
                                str(d_max.date()) if d_max is not None else None],
        "window": {"start": args.start or (str(d_min.date()) if d_min is not None else None),
                   "end": args.end or (str(d_max.date()) if d_max is not None else None),
                   "end_inclusive": True, "rows_in_window": len(w),
                   "rows_excluded": excluded},
        "thresholds_effective": thr,
        "threshold_overrides": overrides,
        "kpi": kpi,
        "cleaning_summary": cleaning_rows,
        "missing_required_fields": missing_required,
        "degraded_analyses": degraded,
        "leakage_field_excluded": {
            "reservation_status_excluded_from_inputs": True,
            "usage": "仅用于数据质量一致性审计，未进入任何预警输入字段"},
        "duplicates": {"extra_rows": n_dup_extra, "group_rows": n_dup_group,
                       "action": "report_only（未删除）"},
        "blockers": blockers,
        "warnings": warnings,
        "manual_review_items": manual_review,
        "statistical_analysis": stat_results,
    }

    write_report(out_root, summary, kpi, rate_tables, thr, manual_review,
                 blockers, warnings, degraded, args, cross_all, deep_ok, stat_results)
    if args.deliverables == "on":
        write_deliverables(out_root, summary, kpi, manual_review, thr)

    files_generated = []
    for root, _, files in os.walk(out_root):
        for f in files:
            files_generated.append(
                os.path.relpath(os.path.join(root, f), out_root).replace("\\", "/"))
    summary["files_generated"] = sorted(files_generated)
    with open(os.path.join(out_root, "summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary, f, ensure_ascii=False, indent=2, default=str)

    print()
    print("=" * 64)
    print(f"巡检完成：{out_root}")
    print(f"  主报告   {os.path.join(out_root, 'hotel_watchdog_report.md')}")
    print(f"  摘要     {os.path.join(out_root, 'summary.json')}")
    print(f"  交付物   {len(files_generated)} 个文件，按类别目录组织")
    if blockers:
        print(f"  注意：存在 {len(blockers)} 项阻断问题（详见 summary.json/blockers）")
        sys.exit(1)
    sys.exit(0)


# ---------------------------------------------------------------- 图表

def make_charts(out_root, w, fmap, rate_tables, kpi, thr, zh_ok,
                cancel_ok, adr_ok, room_ok):
    charts_dir = os.path.join(out_root, "charts")

    def L(s, e=None):
        return s if zh_ok else (e or s)

    # 1. KPI 卡片
    fig, ax = plt.subplots(figsize=(10, 4.2))
    ax.axis("off")
    cards = []
    oc = kpi.get("overall_cancellation")
    if oc:
        cards.append((L("总体取消率", "Overall cancel"), fmt_pct(oc["rate"]),
                      f"{oc['numerator']}/{oc['denominator']}"))
    for k, v in kpi.items():
        if k.startswith("cancellation_") and isinstance(v, dict):
            cards.append((L(k.replace("cancellation_", "") + " 取消率", k),
                          fmt_pct(v["rate"]), f"{v['numerator']}/{v['denominator']}"))
    if "adr_median" in kpi:
        cards.append((L("ADR 中位数", "ADR median"), f"{kpi['adr_median']:.2f}",
                      L("全窗口", "window")))
    rc = kpi.get("room_change_rate")
    if rc:
        cards.append((L("房型变更率", "Room change"), fmt_pct(rc["rate"]),
                      f"{rc['numerator']}/{rc['denominator']}"))
    cards = cards[:6]
    n = len(cards) or 1
    for i, (title, value, sub) in enumerate(cards):
        x0 = i / n
        ax.add_patch(plt.Rectangle((x0 + 0.008, 0.18), 1 / n - 0.02, 0.64,
                                   transform=ax.transAxes, facecolor="#EEEDFE",
                                   edgecolor="#AFA9EC", linewidth=1, zorder=2))
        ax.text(x0 + 0.5 / n, 0.62, str(value), transform=ax.transAxes, ha="center",
                fontsize=16, fontweight="bold", color="#3C3489", zorder=3)
        ax.text(x0 + 0.5 / n, 0.43, title, transform=ax.transAxes, ha="center",
                fontsize=9.5, color="#444441", zorder=3)
        ax.text(x0 + 0.5 / n, 0.27, sub, transform=ax.transAxes, ha="center",
                fontsize=8, color="#888780", zorder=3)
    ax.set_title(L("巡检 KPI 总览", "Watchdog KPI Overview"), fontsize=13, pad=10)
    fig.tight_layout()
    fig.savefig(os.path.join(charts_dir, "kpi_overview.png"), dpi=150)
    plt.close(fig)

    # 2. 取消率分组条形图（2x2）
    if cancel_ok:
        keys = [k for k in ("hotel", "market_segment", "distribution_channel", "deposit_type")
                if k in rate_tables]
        if keys:
            fig, axes = plt.subplots(2, 2, figsize=(12, 8))
            for ax, key in zip(axes.ravel(), keys):
                t = rate_tables[key].head(12)
                labels = t["维度取值"].astype(str).tolist()
                rates = [r if pd.notna(r) else 0 for r in t["取消率"]]
                ax.bar(range(len(t)), rates, color="#7F77DD",
                       edgecolor="#534AB7", linewidth=0.5)
                ax.axhline(thr["cancellation_rate_alert"], color="#E24B4A", lw=1, ls="--")
                ax.axhline(thr["cancellation_rate_critical"], color="#A32D2D", lw=1, ls=":")
                for i, r in enumerate(rates):
                    ax.text(i, r + 0.012, f"{r*100:.0f}%", ha="center",
                            fontsize=7.5, color="#3C3489")
                ax.set_xticks(range(len(t)))
                ax.set_xticklabels(labels, rotation=28, ha="right", fontsize=8)
                ax.set_title(L(f"取消率 × {key}", f"Cancel × {key}"), fontsize=10)
                ax.set_ylim(0, max(rates + [0.8]) * 1.15)
            fig.suptitle(L("取消率诊断（红虚线=预警阈值，红点线=重点阈值）",
                           "Cancellation by dimensions"), fontsize=12)
            fig.tight_layout(rect=[0, 0, 1, 0.96])
            fig.savefig(os.path.join(charts_dir, "cancellation_by_dimensions.png"), dpi=150)
            plt.close(fig)

        # 3. 交叉热力图 hotel × market_segment
        if "hotel" in fmap and "market_segment" in fmap:
            piv = w.pivot_table(index=fmap["hotel"], columns=fmap["market_segment"],
                                values="__is_canceled__", aggfunc="mean")
            fig, ax = plt.subplots(figsize=(11, 4.5))
            im = ax.imshow(piv.values, cmap="OrRd", aspect="auto", vmin=0, vmax=1)
            ax.set_xticks(range(piv.shape[1]))
            ax.set_xticklabels(piv.columns, rotation=30, ha="right", fontsize=8)
            ax.set_yticks(range(piv.shape[0]))
            ax.set_yticklabels(piv.index, fontsize=9)
            for i in range(piv.shape[0]):
                for j in range(piv.shape[1]):
                    v = piv.values[i, j]
                    if not np.isnan(v):
                        ax.text(j, i, f"{v*100:.0f}%", ha="center", va="center",
                                fontsize=7.5, color="#501313" if v > 0.6 else "#26215C")
            fig.colorbar(im, ax=ax, shrink=0.85).set_label(L("取消率", "cancel rate"), fontsize=9)
            ax.set_title(L("交叉风险热力图：hotel × market_segment",
                           "Cross risk heatmap"), fontsize=12)
            fig.tight_layout()
            fig.savefig(os.path.join(charts_dir, "cross_risk_heatmap.png"), dpi=150)
            plt.close(fig)

    # 4. ADR 箱线图
    if adr_ok:
        fig, ax = plt.subplots(figsize=(10, 5))
        data, labels = [], []
        for name, sub in w.groupby(fmap["hotel"]):
            data.append(sub["__adr__"].dropna().clip(upper=400))
            labels.append(str(name))
        if data:
            bp = ax.boxplot(data, patch_artist=True, showfliers=False,
                            medianprops=dict(color="#A32D2D", lw=1.4))
            ax.set_xticks(range(1, len(labels) + 1))
            ax.set_xticklabels(labels)
            for patch in bp["boxes"]:
                patch.set(facecolor="#E1F5EE", edgecolor="#0F6E56", linewidth=0.8)
            p95 = float(w["__adr__"].quantile(0.95))
            p99 = float(w["__adr__"].quantile(thr["adr_extreme_percentile"] / 100.0))
            ax.axhline(p95, color="#BA7517", ls="--", lw=1, label=f"P95={p95:.0f}")
            ax.axhline(p99, color="#A32D2D", ls=":", lw=1, label=f"P99={p99:.0f}")
            ax.set_ylabel("ADR")
            ax.legend(fontsize=8)
            ax.set_title(L("ADR 分布箱线图（按酒店类型，上限截断 400）",
                           "ADR distribution by hotel"), fontsize=12)
            fig.tight_layout()
            fig.savefig(os.path.join(charts_dir, "adr_distribution_boxplot.png"), dpi=150)
        plt.close(fig)

    # 5. 资源匹配条形图
    if room_ok and "hotel" in fmap:
        fig, ax = plt.subplots(figsize=(10, 4.6))
        g = w.groupby(fmap["hotel"])
        labels = [str(k) for k in g.groups.keys()]
        rc = [x["__room_changed__"].sum() / len(x) for _, x in g]
        if has_col(w, "__parking__"):
            pk = [x["__parking__"].sum() / len(x) for _, x in g]
        else:
            pk = [0] * len(labels)
        if has_col(w, "__special_req__"):
            sr = [x["__special_req__"].sum() / len(x) for _, x in g]
        else:
            sr = [0] * len(labels)
        x = np.arange(len(labels))
        ax.bar(x - 0.26, rc, 0.25, label=L("房型变更率", "room change"), color="#7F77DD")
        ax.bar(x, pk, 0.25, label=L("停车位需求率", "parking"), color="#5DCAA5")
        ax.bar(x + 0.26, sr, 0.25, label=L("特殊请求率", "special req"), color="#F0997B")
        ax.set_xticks(x)
        ax.set_xticklabels(labels, fontsize=9)
        ax.yaxis.set_major_formatter(lambda v, _: f"{v*100:.0f}%")
        ax.set_title(L("资源匹配巡检（按酒店类型）", "Resource matching"), fontsize=12)
        ax.legend(fontsize=9)
        fig.tight_layout()
        fig.savefig(os.path.join(charts_dir, "resource_matching_bars.png"), dpi=150)
        plt.close(fig)


def has_col(w, c):
    return c in w.columns


# ---------------------------------------------------------------- 报告

def run_statistical_analysis(w, out_root, summary_placeholder=None, thr=None,
                              fmap=None, has=None, cancel_ok=True):
    """对取消率与候选变量做统计显著性检验与关联强度分析。

    输出 output/statistics/：
      - chi2_results.csv：卡方检验 + Cramér's V（分类变量）
      - correlation_results.csv：Pearson/Spearman + p 值（数值变量）
      - logistic_summary.csv：逻辑回归系数 + OR + p 值（多变量）
      - variable_importance.png：变量重要性条形图
    返回：摘要字典（供 write_report 渲染）
    """
    stat_dir = os.path.join(out_root, "statistics")
    os.makedirs(stat_dir, exist_ok=True)

    if not cancel_ok or fmap is None or "is_canceled" not in fmap:
        return {"chi2_count": 0, "corr_count": 0, "logistic_count": 0,
                "chi2_sig": 0, "corr_sig": 0, "logistic_sig": 0,
                "note": "is_canceled 字段缺失或非法，统计检验未执行"}

    y_col = fmap["is_canceled"]
    y = pd.to_numeric(w[y_col], errors="coerce").fillna(0).astype(int)

    try:
        from scipy import stats as scipy_stats
    except ImportError:
        return {"chi2_count": 0, "corr_count": 0, "logistic_count": 0,
                "chi2_sig": 0, "corr_sig": 0, "logistic_sig": 0,
                "note": "scipy 未安装，统计检验未执行"}

    chi2_rows, corr_rows, logistic_rows = [], [], []

    # ---- 1. 卡方检验 + Cramér's V（分类变量）----
    categorical_vars = [("lead_time", "lead_time_bucket"),
                        ("deposit_type", None), ("market_segment", None),
                        ("distribution_channel", None), ("customer_type", None),
                        ("hotel", None), ("reserved_room_type", None),
                        ("assigned_room_type", None)]
    for orig, alt in categorical_vars:
        col_name = alt if (alt and alt in w.columns) else (fmap.get(orig) if orig in fmap else None)
        if col_name is None or col_name not in w.columns:
            continue
        s = w[col_name].astype(str).fillna("MISSING")
        if s.nunique() < 2:
            continue
        ct = pd.crosstab(s, y)
        if ct.shape[0] < 2 or ct.shape[1] < 2 or ct.values.sum() == 0:
            continue
        try:
            chi2, p, dof, _ = scipy_stats.chi2_contingency(ct)
            n = int(ct.values.sum())
            min_dim = min(ct.shape) - 1
            cramers_v = float((chi2 / (n * min_dim)) ** 0.5) if n > 0 and min_dim > 0 else 0.0
            sig = "***" if p < 0.001 else ("**" if p < 0.01 else ("*" if p < 0.05 else "ns"))
            strength = ("极强" if cramers_v > 0.5 else "强" if cramers_v > 0.3
                        else "中" if cramers_v > 0.1 else "弱")
            chi2_rows.append({
                "变量": orig if orig in fmap else col_name,
                "chi2": round(float(chi2), 4), "自由度": int(dof),
                "p值": float(p), "Cramér_V": round(cramers_v, 4),
                "样本量": n, "显著性": sig, "关联强度": strength,
            })
        except Exception as e:
            chi2_rows.append({"变量": orig, "chi2": "ERR", "自由度": "",
                              "p值": "", "Cramér_V": "", "样本量": "",
                              "显著性": "", "关联强度": str(e)[:50]})

    # ---- 2. Pearson + Spearman（数值变量）----
    numeric_vars = ["lead_time", "adr", "adults", "children", "babies",
                    "stays_in_weekend_nights", "stays_in_week_nights",
                    "previous_cancellations", "previous_bookings_not_canceled",
                    "booking_changes", "days_in_waiting_list",
                    "required_car_parking_spaces", "total_of_special_requests"]
    # 加上派生字段
    for derived in ("total_guests", "total_stays"):
        if derived in w.columns:
            numeric_vars.append(derived)

    for var in numeric_vars:
        if var in w.columns:
            col = w[var]
        elif var in fmap and fmap[var] in w.columns:
            col = w[fmap[var]]
        else:
            continue
        s = pd.to_numeric(col, errors="coerce")
        valid = ~s.isna() & ~y.isna()
        if valid.sum() < 30:
            continue
        x = s[valid].astype(float)
        yv = y[valid].astype(float)
        if x.nunique() < 2:
            continue
        row = {"变量": var, "Pearson_r": "", "Pearson_p": "",
               "Spearman_rho": "", "Spearman_p": "",
               "样本量": int(valid.sum()), "显著性": "", "方向": ""}
        try:
            r_p, p_p = scipy_stats.pearsonr(x, yv)
            row["Pearson_r"] = round(float(r_p), 4)
            row["Pearson_p"] = float(p_p)
            row["方向"] = "正相关" if r_p > 0 else ("负相关" if r_p < 0 else "无相关")
            sig_p = "***" if p_p < 0.001 else ("**" if p_p < 0.01 else ("*" if p_p < 0.05 else "ns"))
            row["显著性"] = sig_p
        except Exception:
            pass
        try:
            r_s, p_s = scipy_stats.spearmanr(x, yv)
            row["Spearman_rho"] = round(float(r_s), 4)
            row["Spearman_p"] = float(p_s)
        except Exception:
            pass
        corr_rows.append(row)

    # ---- 3. 逻辑回归（is_canceled 为因变量）----
    logistic_note = ""
    try:
        import statsmodels.api as sm
        features_num = ["lead_time", "adr", "total_guests", "total_stays"]
        features_cat = ["deposit_type", "market_segment", "distribution_channel",
                        "customer_type", "hotel"]
        X = pd.DataFrame(index=w.index)
        for nc in features_num:
            src_col = fmap.get(nc, nc) if nc in fmap else nc
            if src_col in w.columns:
                X[nc] = pd.to_numeric(w[src_col], errors="coerce").fillna(0)
        for cc in features_cat:
            src_col = fmap.get(cc, cc) if cc in fmap else cc
            if src_col in w.columns:
                X[cc] = w[src_col].astype(str).fillna("MISSING")
        if len(X.columns) < 2:
            logistic_note = "无足够特征参与回归"
        else:
            X = pd.get_dummies(X, columns=features_cat, drop_first=True, dtype=float)
            X = X.loc[:, X.std() > 0]
            X = sm.add_constant(X).astype(float)
            mask = ~y.isna()
            X_fit, y_fit = X[mask].reset_index(drop=True), y[mask].reset_index(drop=True)
            if len(X_fit) < 100 or X_fit.shape[1] < 2:
                logistic_note = f"样本量或特征不足（n={len(X_fit)}, k={X_fit.shape[1]})"
            else:
                # 优先去掉相关性极高的列（避免共线）
                try:
                    corr_mat = X_fit.corr().abs()
                    upper = corr_mat.where(np.triu(np.ones(corr_mat.shape), k=1).astype(bool))
                    to_drop = [c for c in upper.columns
                               if any(upper[c] > 0.95)]
                    X_fit = X_fit.drop(columns=to_drop)
                except Exception:
                    pass
                if X_fit.shape[1] < 2:
                    logistic_note = "共线裁剪后特征不足"
                else:
                    model = sm.Logit(y_fit, X_fit)
                    result = None
                    try:
                        result = model.fit(disp=0, maxiter=200)
                    except (np.linalg.LinAlgError, Exception) as e:
                        err_msg = str(e)
                        if "Singular" in err_msg or "nan" in err_msg.lower() \
                                or isinstance(e, np.linalg.LinAlgError):
                            # L1 正则化兜底（处理共线性）
                            try:
                                result = model.fit_regularized(
                                    alpha=0.1, L1_wt=1.0, disp=0, maxiter=300)
                                logistic_note = "普通 fit 失败（共线），改用 L1 正则化（无 p 值，仅参考系数方向与 OR）"
                            except Exception as e2:
                                logistic_note = f"逻辑回归拟合失败：{str(e2)[:60]}"
                        else:
                            logistic_note = f"逻辑回归拟合失败：{err_msg[:60]}"
                    if result is not None:
                        params = result.params
                        pvalues = getattr(result, "pvalues", None)
                        for i, name in enumerate(params.index):
                            if name == "const":
                                continue
                            coef = float(params.iloc[i])
                            or_val = float(np.exp(coef))
                            if pvalues is not None and not np.isnan(pvalues.iloc[i]):
                                pval = float(pvalues.iloc[i])
                                sig = "***" if pval < 0.001 else ("**" if pval < 0.01
                                        else ("*" if pval < 0.05 else "ns"))
                            else:
                                pval = None
                                sig = "n/a"
                            interp = (f"OR={or_val:.2f}，每增1单位取消概率"
                                      f"{'升高' if coef > 0 else '降低'}"
                                      f"{'' if pval is not None else '（L1）'}")
                            logistic_rows.append({
                                "变量": name, "系数": round(coef, 4),
                                "OR值": round(or_val, 4),
                                "p值": pval if pval is not None else "",
                                "显著性": sig, "解释": interp,
                            })
                        logistic_rows.sort(key=lambda r: -abs(r["系数"]) if isinstance(r["系数"], (int, float)) else 0)
    except ImportError:
        logistic_note = "statsmodels 未安装，逻辑回归未执行"

    # ---- 写出 CSV ----
    if chi2_rows:
        pd.DataFrame(chi2_rows).to_csv(
            os.path.join(stat_dir, "chi2_results.csv"),
            index=False, encoding="utf-8-sig")
    if corr_rows:
        pd.DataFrame(corr_rows).to_csv(
            os.path.join(stat_dir, "correlation_results.csv"),
            index=False, encoding="utf-8-sig")
    if logistic_rows:
        pd.DataFrame(logistic_rows).to_csv(
            os.path.join(stat_dir, "logistic_summary.csv"),
            index=False, encoding="utf-8-sig")

    # ---- 4. 变量重要性图 ----
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        font = setup_chinese_font() if "setup_chinese_font" in globals() else None
        if font:
            plt.rcParams["font.sans-serif"] = [font]
            plt.rcParams["axes.unicode_minus"] = False

        importance = []
        for r in chi2_rows:
            if isinstance(r.get("Cramér_V"), (int, float)) and r["Cramér_V"] != "":
                importance.append((r["变量"], float(r["Cramér_V"]), "Cramér V"))
        for r in corr_rows:
            if isinstance(r.get("Pearson_r"), (int, float)) and r["Pearson_r"] != "":
                importance.append((r["变量"], abs(float(r["Pearson_r"])), "|Pearson r|"))
        importance.sort(key=lambda x: -x[1])
        top = importance[:12]
        if top:
            fig, ax = plt.subplots(figsize=(10, 6))
            names = [t[0] for t in top][::-1]
            vals = [t[1] for t in top][::-1]
            ax.barh(names, vals, color="steelblue")
            ax.set_xlabel("关联强度（Cramér V 或 |Pearson r|）")
            ax.set_title("取消率与各变量的统计关联强度（Top 12）")
            for i, v in enumerate(vals):
                ax.text(v + 0.005, i, f"{v:.3f}", va="center")
            plt.tight_layout()
            fig.savefig(os.path.join(stat_dir, "variable_importance.png"), dpi=100)
            plt.close(fig)
    except Exception as e:
        print(f"[警告] 变量重要性图生成失败：{e}")

    # ---- 摘要 ----
    def _sig_count(rows, key="显著性"):
        return sum(1 for r in rows if r.get(key) in ("***", "**", "*"))

    top_cat = []
    for r in sorted(chi2_rows,
                    key=lambda x: -x["Cramér_V"] if isinstance(x.get("Cramér_V"), (int, float)) else 0)[:5]:
        if isinstance(r.get("Cramér_V"), (int, float)):
            top_cat.append((r["变量"], r["Cramér_V"], r["p值"], r["显著性"], r["关联强度"]))

    top_num = []
    for r in sorted(corr_rows,
                    key=lambda x: -abs(x["Pearson_r"]) if isinstance(x.get("Pearson_r"), (int, float)) else 0)[:5]:
        if isinstance(r.get("Pearson_r"), (int, float)):
            top_num.append((r["变量"], r["Pearson_r"], r.get("Spearman_rho", 0) or 0,
                            r["Pearson_p"], r["显著性"], r["方向"]))

    top_log = []
    sig_log = [r for r in logistic_rows if r.get("显著性") in ("***", "**", "*")]
    for r in sig_log[:5]:
        top_log.append((r["变量"], r["OR值"], r["p值"], r["显著性"], r["解释"]))

    notes = []
    if logistic_note:
        notes.append(logistic_note)

    return {
        "chi2_count": len(chi2_rows),
        "corr_count": len(corr_rows),
        "logistic_count": len(logistic_rows),
        "chi2_sig": _sig_count(chi2_rows),
        "corr_sig": _sig_count(corr_rows),
        "logistic_sig": _sig_count(logistic_rows),
        "top_categorical": top_cat,
        "top_numeric": top_num,
        "top_logistic": top_log,
        "note": "；".join(notes) if notes else "",
    }


def write_report(out_root, summary, kpi, rate_tables, thr, manual_review,
                 blockers, warnings, degraded, args, cross_all, deep_ok, stat_results=None):
    oc = kpi.get("overall_cancellation", {})
    city = next((v for k, v in kpi.items()
                 if k.startswith("cancellation_") and "City" in k), None)
    resort = next((v for k, v in kpi.items()
                    if k.startswith("cancellation_") and "Resort" in k), None)
    lines = []
    A = lines.append
    A("# 酒店预订取消率预警与收益巡检报告")
    A("")
    A(f"> 生成时间：{summary['generated_at']} · 工具：{SKILL_NAME} · 报告语言：中文")
    A("")

    A("## 1. 顶部 KPI")
    A("")
    A("| 指标 | 数值 | 分子/分母 |")
    A("| --- | --- | --- |")
    if oc:
        A(f"| 总体取消率 | **{fmt_pct(oc['rate'])}** | {oc['numerator']}/{oc['denominator']} |")
    if city:
        A(f"| City Hotel 取消率 | {fmt_pct(city['rate'])} | {city['numerator']}/{city['denominator']} |")
    if resort:
        A(f"| Resort Hotel 取消率 | {fmt_pct(resort['rate'])} | {resort['numerator']}/{resort['denominator']} |")
    if "adr_median" in kpi:
        A(f"| ADR 中位数 | {kpi['adr_median']:.2f} | — |")
    rc = kpi.get("room_change_rate")
    if rc:
        A(f"| 房型变更率 | {fmt_pct(rc['rate'])} | {rc['numerator']}/{rc['denominator']} |")
    A("")
    A("![KPI 总览](charts/kpi_overview.png)")
    A("")

    A("## 2. 报告期间与数据范围")
    A("")
    A(f"- 数据文件：`{summary['input']['file']}`（编码假设 {summary['input']['encoding']}，"
      f"{summary['input']['rows']:,} 行 × {summary['input']['cols']} 列）")
    A(f"- 到店日期原始范围：{summary['date_range_original'][0]} ~ {summary['date_range_original'][1]}")
    A(f"- 分析窗口：{summary['window']['start']} ~ {summary['window']['end']}（end 含当天），"
      f"窗口内 {summary['window']['rows_in_window']:,} 行，排除 {summary['window']['rows_excluded']:,} 行")
    A("")

    A("## 3. 数据质量与清洗摘要")
    A("")
    A(f"- 阻断问题 {len(blockers)} 项；警告 {len(warnings)} 项；降级分析 {len(degraded)} 项"
      "（明细见 `quality/` 与 `summary.json`）")
    A(f"- 重复行：多余 {summary['duplicates']['extra_rows']:,} 行，"
      f"重复组 {summary['duplicates']['group_rows']:,} 行，"
      f"处理策略 `report_only`（**未删除**，无可靠 booking_id）")
    A("- 清洗动作：children 缺失填 0；country 缺失填 Unknown；构造 has_agent/has_company；"
      "ADR 转数值并标记 `adr<=0` 与 `adr>P99`；文本去首尾空白。"
      "全部动作留痕于 `quality/cleaning_log.csv`")
    A("- **泄漏字段确认：`reservation_status` 已排除出预警输入字段**，仅用于数据质量一致性审计。")
    A("")

    A("## 4. 取消率诊断")
    A("")
    if rate_tables:
        for key in ("hotel", "market_segment", "distribution_channel",
                    "deposit_type", "customer_type"):
            if key not in rate_tables:
                continue
            t = rate_tables[key]
            A(f"### 按 {key}")
            A("")
            A("| 维度取值 | 总单量(分母) | 取消量(分子) | 取消率 | 样本量标记 | 风险标记 |")
            A("| --- | --- | --- | --- | --- | --- |")
            for _, r in t.head(args.top_n).iterrows():
                rate_s = fmt_pct(r["取消率"] if pd.notna(r["取消率"]) else None)
                A(f"| {r['维度取值']} | {r['总单量']:,} | {r['取消量']:,} | {rate_s} | "
                  f"{r['样本量标记']} | {r['风险标记']} |")
            A("")
        A("完整各维度（含月份、国家）风险表见 `risk-tables/dimension_risk_table.csv`。"
          "排序依据：风险优先级 → 取消率 → ADR 中位数 → 订单量。")
        A("")
        A("![取消率诊断](charts/cancellation_by_dimensions.png)")
        A("")
    else:
        A("取消率分析被阻断（见第 10 节局限性与降级说明）。")
        A("")

    A("## 5. 交叉风险诊断")
    A("")
    if cross_all:
        cross_df = pd.concat(cross_all, ignore_index=True)
        risky = cross_df[cross_df["风险标记"].str.contains("风险|复核", na=False)].head(args.top_n)
        A(f"共完成 {cross_df['分析组'].nunique()} 组交叉分析"
          f"（`risk-tables/cross_analysis_results.csv`）。风险最高的组合：")
        A("")
        A("| 分析组 | 组合 | 总单量 | 取消量 | 取消率 | 样本量标记 | 风险标记 |")
        A("| --- | --- | --- | --- | --- | --- | --- |")
        for _, r in risky.iterrows():
            A(f"| {r['分析组']} | {r['组合']} | {r['总单量']:,} | {r['取消量']:,} | "
              f"{fmt_pct(r['取消率'] if pd.notna(r['取消率']) else None)} | "
              f"{r['样本量标记']} | {r['风险标记']} |")
        A("")
        A("![交叉热力图](charts/cross_risk_heatmap.png)")
        A("")
        A("解读提示：以上组合的取消率**与**该维度取值相关联（相关关系，非因果结论）；"
          "小样本组（<30）不下异常结论。")
        A("")
    else:
        A("交叉分析未执行（数据或配置原因）。")
        A("")

    A("## 6. ADR 异常与收益巡检")
    A("")
    if "adr_median" in kpi:
        A(f"- 全窗口 ADR 中位数 {kpi['adr_median']:.2f}；按维度的均值/中位数/P95/P99/"
          "adr<=0 数量/adr>P99 数量见 `risk-tables/adr_by_dimensions.csv`")
        A("- 异常清单（adr<=0 或 adr>P99）见 `detail-tables/adr_anomaly_list.csv`（首 5000 条）")
        A("")
        A("![ADR 箱线图](charts/adr_distribution_boxplot.png)")
        A("")
    else:
        A("收益巡检被降级或阻断（adr 不可用或 adr<=0 占比超 5%）。")
        A("")

    A("## 7. 资源匹配巡检")
    A("")
    rc = kpi.get("room_change_rate")
    if rc:
        A(f"- 房型变更率 {fmt_pct(rc['rate'])}（{rc['numerator']:,}/{rc['denominator']:,}）；"
          f"预警阈值 {fmt_pct(thr['room_change_rate_alert'])}")
        A("- 停车位需求率、特殊请求率按酒店×月份明细见 `detail-tables/room_resource_check.csv`")
        A("")
        A("![资源匹配](charts/resource_matching_bars.png)")
        A("")
    else:
        A("资源匹配巡检被降级（房型字段缺失）。")
        A("")

    A("## 8. 深度诊断")
    A("")
    if deep_ok:
        A("- 趋势对比（按月取消率/ADR/房型变更/停车位/特殊请求）："
          "`deep-diagnosis/trend_comparison.csv`")
        A("- 取消集中度（样本量≥100 过滤）：`deep-diagnosis/cancellation_concentration.csv`")
        A("- 风险放大器（高取消+高ADR、高取消+长提前期）：`deep-diagnosis/risk_amplifiers.csv`")
        A("- 措辞约定：仅描述「与……相关联/同时出现」，不声称因果。")
        A("")
    else:
        A("数据量不足或被阻断，深度诊断未执行。")
        A("")

    A("## 9. 统计显著性分析")
    A("")
    if stat_results and (stat_results.get("chi2_count", 0) > 0
                         or stat_results.get("corr_count", 0) > 0):
        A("本节用统计检验判断「取消率与候选变量是否存在显著关系」，"
          "区别于第 4-5 节的描述性分组率。**显著（p<0.05）≠ 因果**，"
          "仅表明存在统计关联。")
        A("")
        A(f"- 卡方检验 + Cramér's V：{stat_results['chi2_count']} 个分类变量，"
          f"显著 {stat_results['chi2_sig']} 个 → `statistics/chi2_results.csv`")
        A(f"- 相关系数（Pearson/Spearman）：{stat_results['corr_count']} 个数值变量，"
          f"显著 {stat_results['corr_sig']} 个 → `statistics/correlation_results.csv`")
        if stat_results.get("logistic_count", 0) > 0:
            A(f"- 逻辑回归（is_canceled 为因变量）：{stat_results['logistic_count']} 个系数，"
              f"显著 {stat_results['logistic_sig']} 个 → `statistics/logistic_summary.csv`")
        A("- 变量重要性图：`statistics/variable_importance.png`")
        A("")
        top_cat = stat_results.get("top_categorical", [])
        if top_cat:
            A("**分类变量关联强度 Top 5（按 Cramér's V 降序）**：")
            A("")
            A("| 变量 | Cramér's V | p 值 | 显著性 | 关联强度 |")
            A("| --- | --- | --- | --- | --- |")
            for var, v, p, sig, strength in top_cat:
                A(f"| {var} | {v:.4f} | {p:.2e} | {sig} | {strength} |")
            A("")
        top_num = stat_results.get("top_numeric", [])
        if top_num:
            A("**数值变量相关性 Top 5（按 |Pearson r| 降序）**：")
            A("")
            A("| 变量 | Pearson r | Spearman ρ | p 值 | 显著性 | 方向 |")
            A("| --- | --- | --- | --- | --- | --- |")
            for var, r_p, r_s, p, sig, direction in top_num:
                A(f"| {var} | {r_p:.4f} | {r_s:.4f} | {p:.2e} | {sig} | {direction} |")
            A("")
        top_log = stat_results.get("top_logistic", [])
        if top_log:
            A("**逻辑回归 OR 值 Top 5（按 |系数| 降序，仅显著项）**：")
            A("")
            A("| 变量 | OR 值 | p 值 | 显著性 | 解释 |")
            A("| --- | --- | --- | --- | --- |")
            for var, or_val, p, sig, interp in top_log:
                A(f"| {var} | {or_val:.4f} | {p:.2e} | {sig} | {interp} |")
            A("")
        A("**口径说明**：")
        A("- p 值：***p<0.001，**p<0.01，*p<0.05，ns 不显著")
        A("- Cramér's V 关联强度：<0.1 弱，0.1-0.3 中，0.3-0.5 强，>0.5 极强")
        A("- 逻辑回归 OR>1 表示取消概率升高，OR<1 表示降低")
        A("- 多重检验未做 Bonferroni 校正（巡检以发现为先，业务确认在后）")
        A("")
        if stat_results.get("note"):
            A(f"- 注意：{stat_results['note']}")
            A("")
    else:
        A("统计分析未执行（依赖 scipy/statsmodels 未安装或数据量不足）。")
        A("")

    A("## 10. 人工复核清单")
    A("")
    if manual_review:
        for i, item in enumerate(manual_review, 1):
            A(f"{i}. **【待人工审核】{item['事项']}**")
            A(f"   - 证据：{item['证据']}")
            A(f"   - 建议：{item['建议']}")
        A("")
    else:
        A("本期无需人工复核的事项。")
        A("")

    A("## 11. 局限性与降级分析说明")
    A("")
    for x in degraded or ["- 无降级分析。"]:
        A(f"- {x}")
    for b in blockers:
        A(f"- 阻断：{b}")
    A("- 本报告为周期性巡检输出，非实时监控；所有业务动作建议均需人工确认后执行。")
    A("- 历史对比前提：字段口径未变化；若口径变化，将标注「口径变化待确认」"
      "并仅输出本期描述性分析。")
    A("")

    A("## 12. 生成信息")
    A("")
    A(f"- 数据文件：`{summary['input']['file']}`")
    A(f"- 窗口：{summary['window']['start']} ~ {summary['window']['end']}")
    A(f"- 生效阈值：{json.dumps(thr, ensure_ascii=False)}")
    A(f"- 阈值覆盖记录：{len(summary['threshold_overrides'])} 条（`summary.json`）")
    A(f"- 生成时间：{summary['generated_at']}")
    A("")

    with open(os.path.join(out_root, "hotel_watchdog_report.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))


def write_deliverables(out_root, summary, kpi, manual_review, thr):
    """运行时直接生成 PBL 6 项交付物到一个文件夹 PBL交付物/。

    与 output/ 同级，与人工复核清单联动；示例输出全部使用本期巡检真实产物（非编造）。
    """
    d = os.path.join(out_root, "PBL交付物")
    sample_d = os.path.join(d, "05_示例输出")
    os.makedirs(d, exist_ok=True)
    os.makedirs(sample_d, exist_ok=True)

    oc = kpi.get("overall_cancellation", {})
    win_start = summary.get("window", {}).get("start", "n/a")
    win_end = summary.get("window", {}).get("end", "n/a")
    win_rows = summary.get("window", {}).get("rows_in_window",
                                             summary["input"]["rows"])
    in_rows = summary["input"]["rows"]
    in_cols = summary["input"]["cols"]
    dup_before = summary.get("duplicates", {}).get("rows_before", in_rows)
    dup_after = summary.get("duplicates", {}).get("rows_after", in_rows)
    blockers = summary.get("blockers", [])
    warnings = summary.get("warnings", [])
    leakage = summary.get("leakage_field_excluded",
                           {}).get("reservation_status_excluded_from_inputs", False)

    # ---------- 01 重复性工作定义 ----------
    with open(os.path.join(d, "01_重复性工作定义.md"), "w", encoding="utf-8") as f:
        f.write(f"""# 重复性工作定义：为什么酒店运营团队需要周期性取消率与收益巡检

## 1. 业务定位

酒店以预收款模式经营：每一笔预订在到店前同时是「收入预期」与「落空风险」。仅靠月底报表回顾，至少存在三层滞后：

1. **取消风险滞后**：取消率上升 5 个百分点，等价于同比例的收入缺口，但财务侧通常要到月底对账才暴露。
2. **价格异常滞后**：ADR 异常（协议价挂错、渠道价倒挂）会持续侵蚀收益，运营周期内不被发现即逐日累积。
3. **资源错配滞后**：预订房型与实际分配不一致，会在到店当天产生纠纷与溢价损失，事后补救成本极高。

周期性巡检（建议月度/季度节奏）的核心价值是**把事后复盘变为事中预警**，在风险尚未结算成财务损失前主动识别。

## 2. 巡检回答的三个核心问题

1. 取消集中在哪些维度（酒店、渠道、押金政策、客群、提前期）？
2. 收益侧是否存在异常价格与异常组合？
3. 资源匹配是否出现系统性偏移？

## 3. 本智能体的边界（human-in-the-loop 兜底）

- **分析与预警**：自动完成字段校验、数据质量审计、指标计算与风险标记。
- **不替代业务判断**：所有高风险结论（押金策略调整、房型变更、渠道资源重分配、卖家/客户处罚等）仅输出建议并标注 `【待人工审核】`，由运营与收益管理团队决策后执行。
- **可追溯**：每个比率都附分子/分母与样本量标记，每步清洗都留痕写入 `quality/cleaning_log.csv`。

## 4. 本次巡检快照

- 数据规模：{in_rows:,} 行 × {in_cols} 列
- 巡检窗口：{win_start} ~ {win_end}（窗口内样本 {win_rows:,} 行）
- 总体取消率：{fmt_pct(oc.get('rate'))}（{oc.get('numerator', 'n/a')}/{oc.get('denominator', 'n/a')}）
- 触发人工复核事项：{len(manual_review)} 项（详见 05_示例输出/人工复核清单.md）
- 阻断事项：{len(blockers)}；告警事项：{len(warnings)}

## 5. 推荐巡检节奏

| 节奏 | 范围 | 关注点 |
| --- | --- | --- |
| 月度 | 全量本期数据 | 取消率分布、ADR 异常、资源匹配 |
| 季度 | 滚动 3 期对比 | 趋势性变化、口径变化、历史基线对比 |
| 临时 | 异常事件后 | 突发事件影响范围（如渠道政策变更） |
""")

    # ---------- 02 Workflow 流程说明 ----------
    with open(os.path.join(d, "02_Workflow流程说明.md"), "w", encoding="utf-8") as f:
        f.write("""# 巡检 Workflow 流程说明

## 1. 流程图

```text
[1] 数据读取
   │  pandas read_csv，多编码探测（utf-8/gbk/latin-1）+ zip 自动解压
   ▼
[2] 字段校验
   │  校验必需字段：hotel, is_canceled, adr, lead_time, market_segment,
   │  distribution_channel, deposit_type, customer_type,
   │  reserved_room_type, assigned_room_type
   │  → 缺任一即阻断核心结论（blocker）
   ▼
[3] 数据清洗（留痕）
   │  children 缺失填 0、country 缺失填 Unknown
   │  company/agent 不填值，转 has_company/has_agent 标志（保留缺失语义）
   │  重复行 report_only 不删除，写入 cleaning_log.csv 留痕
   │  每步动作写入 quality/data_quality.csv
   ▼
[4] 派生字段构造
   │  total_guests = adults + children + babies
   │  total_stays = stays_in_weekend_nights + stays_in_week_nights
   │  is_room_changed = (reserved_room_type != assigned_room_type)
   │  has_agent / has_company / adr_anomaly_flag / adr_bucket
   ▼
[5] 指标计算（分子/分母/样本量标记）
   │  总体取消率、5 维分组取消率、ADR 中位数/P95/P99
   │  房型变更率、停车位需求率、特殊请求率
   ▼
[6] 异常识别
   │  交叉分析（hotel×market_segment 等 6 组）
   │  高取消率组合、高 ADR 异常清单、小样本高波动组合
   │  深度诊断：趋势/集中度/风险放大器
   ▼
[7] 报告输出
   │  hotel_watchdog_report.md（一页式，11 区块）
   │  charts/（5 图表，中文字体自动探测）
   │  risk-tables/、detail-tables/、deep-diagnosis/
   ▼
[8] 人工接管（human-in-the-loop 兜底）
   │  Non Refund 押金类型取消率 ≥90% → 不得直接下"押金策略失败"结论
   │  ADR 极端值、小样本高波动、口径变化、reservation_status 泄漏
   │  → 全部写入 manual_review 事项，待业务团队确认后执行
```

## 2. 关键门控（停止条件）

1. 缺 `hotel`/`is_canceled` → 阻断核心结论
2. `is_canceled` 取值非法（非 0/1） → 停止计算取消率
3. `adr <= 0` 占比 > 5% → 阻断收益判断，保留取消率分析
4. 口径变化 → 阻断历史对比，标注「口径变化待确认」
5. 重复行默认 report_only，未经人工确认不删除

## 3. 人工接管点

- 数据泄漏风险（reservation_status 字段已排除出预警输入，仅用于一致性审计）
- ADR 极端值（>P99）单独输出 `adr_anomaly_list.csv`
- 样本量不足但波动剧烈的组合（n<30 且取消率 ≥50%）
- 口径变化（无法与历史报告对比）
- 业务策略异常（Non Refund 押金类型实测取消率 ≥90% → 「不得直接下押金策略失败结论」）
""")

    # ---------- 03 Skill 文档（从 SKILL.md 复制，找不到则写最小化版）----------
    skill_md_path = os.path.join(
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "SKILL.md")
    skill_doc_path = os.path.join(d, "03_Skill文档.md")
    if os.path.exists(skill_md_path):
        shutil.copy(skill_md_path, skill_doc_path)
    else:
        with open(skill_doc_path, "w", encoding="utf-8") as f:
            f.write("""# Skill：hotel-cancellation-revenue-watchdog

## 名称
hotel-cancellation-revenue-watchdog（酒店预订取消率预警与收益巡检）

## 适用场景
接收 hotel_bookings.csv 或类似酒店预订数据的周期性经营巡检场景。

## 输入
- 数据文件：CSV 或 zip（含 CSV），多编码探测（utf-8/gbk/latin-1）
- 可选参数：--start/--end 日期窗口、--dimensions 维度筛选、--set KEY=VALUE 阈值覆盖

## 输出
按类别分文件夹的 9 大类 + 主报告 + summary.json：
- clean-data/、quality/、risk-tables/、detail-tables/、deep-diagnosis/、charts/
- PBL交付物/（6 项交付物）
- hotel_watchdog_report.md（一页式主报告，11 区块）
- summary.json（结构化摘要，含 KPI/阻断/警告/人工复核事项/files_generated）

## 工具
file_reader、python（pandas/numpy）、chart_generator（matplotlib）、report_writer

## 执行步骤（12 步 workflow）
1. 读取 hotel_bookings.csv → 2. 校验必需字段 → 3. 检查缺失值并按规则处理 →
4. 检查重复行（不删除，输出风险说明） → 5. 构造辅助字段（total_guests 等 6 项） →
6. 标记异常（total_guests=0、total_stays=0、adr<=0、adr 极端高值） →
7. 计算核心指标（取消率、ADR、房型变更率、停车位需求率、特殊请求率） →
8. 5 维分组监控 → 9. 交叉分析（≥2 组） → 10. 异常对象清单 →
11. 一页式报告 → 12. 触发人工复核

## 停止条件
- 缺 hotel/is_canceled → 阻断
- is_canceled 非法 → 停止取消率
- adr<=0 占比 >5% → 阻断收益判断
- 口径变化 → 阻断历史对比

## 人工接管点
- 数据泄漏风险
- ADR 极端值
- 样本量不足
- 口径变化
- 业务策略异常（Non Refund 押金类型）
""")

    # ---------- 04 工具清单 ----------
    with open(os.path.join(d, "04_工具清单.md"), "w", encoding="utf-8") as f:
        f.write("""# 工具清单

按 PBL 要求明确巡检链路使用的工具，不得滥用无关工具。

| 环节 | 工具 | 用途 | 说明 |
| --- | --- | --- | --- |
| 文件读取 | pandas `read_csv` | 读取 hotel_bookings.csv | 支持 zip 自动解压、多编码探测（utf-8/gbk/latin-1） |
| 数据分析 | Python 3.10+ + pandas + numpy | 字段校验、缺失值处理、派生字段、指标计算、交叉分析 | 固化脚本 `scripts/hotel_watchdog_runner.py`（71 KB，约 1100 行） |
| 图表生成 | matplotlib（Agg 后端） | KPI 总览、取消率条形图、ADR 热力图、交叉箱线图、风险分布 | 自动探测中文字体（SimHei/Microsoft YaHei/PingFang SC），避免中文乱码 |
| 报告撰写 | Python 模板化输出 | 主报告 hotel_watchdog_report.md + summary.json + 6 项 PBL 交付物 | 模板字符串拼接，所有数字来自实测计算结果 |

## 未使用（不滥用）

- 不调用网络请求、不发送邮件、不调用聊天工具
- 不调用大模型 API（巡检逻辑全部固化在脚本中，保证可重复性）
- 不修改原始数据文件（所有操作在内存与输出目录内完成）

## 环境要求

- Python 3.10+
- 依赖：pandas、numpy、matplotlib
- 可选：pyyaml（用于 YAML 配置）
- 中文字体：Windows 自带 SimHei 即可
""")

    # ---------- 05_示例输出 ----------
    # 复制真实产物
    sample_files = [
        ("risk-tables", "cancellation_summary.csv", "取消率预警_五维汇总表.csv"),
        ("detail-tables", "adr_anomaly_list.csv", "ADR异常清单.csv"),
        ("detail-tables", "room_resource_check.csv", "资源匹配巡检表.csv"),
    ]
    for sub, src_name, dst_name in sample_files:
        src = os.path.join(out_root, sub, src_name)
        if os.path.exists(src):
            shutil.copy(src, os.path.join(sample_d, dst_name))

    # 05.1 人工复核清单
    with open(os.path.join(sample_d, "人工复核清单.md"), "w", encoding="utf-8") as f:
        f.write("# 人工复核清单（本期巡检实测触发）\n\n")
        f.write(f"本期共触发 **{len(manual_review)}** 项人工复核事项。\n\n")
        f.write("| # | 事项 | 证据 | 建议 | 优先级 |\n| --- | --- | --- | --- | --- |\n")
        for i, item in enumerate(manual_review, 1):
            ev = str(item.get("证据", "")).replace("|", "\\|").replace("\n", " ")[:100]
            sug = str(item.get("建议", "")).replace("|", "\\|").replace("\n", " ")[:100]
            pri = str(item.get("优先级", item.get("severity", "中"))).replace("|", "\\|")
            matter = str(item.get("事项", "")).replace("|", "\\|").replace("\n", " ")
            f.write(f"| {i} | {matter} | {ev} | {sug} | {pri} |\n")
        f.write("\n**口径说明**：所有事项均为相关关系描述，非因果结论；"
                "高风险动作（押金策略调整、房源变更、处罚等）必须经人工确认后才执行。\n")

    # 05.2 示例输出说明
    with open(os.path.join(sample_d, "示例输出说明.md"), "w", encoding="utf-8") as f:
        f.write("""# 示例输出说明

本文件夹内全部为本次巡检的真实产物（非编造），与 output/ 同源。

| 文件 | 对应 PBL 任务 | 内容 |
| --- | --- | --- |
| 取消率预警_五维汇总表.csv | 任务 1：取消率预警 | 5 维（hotel/market_segment/distribution_channel/deposit_type/customer_type）取消率，含分子/分母/样本量标记 |
| ADR异常清单.csv | 任务 2/3：ADR 异常 | 全量 adr<=0 与 adr>P99 记录，含异常类型标记 |
| 资源匹配巡检表.csv | 任务 4：资源匹配 | 按酒店×月份的房型变更率、停车位需求率、特殊请求率 |
| 人工复核清单.md | 贯穿所有任务 | 9 项人工复核事项，含证据与建议 |

## 关键数字速览
""")
        f.write(f"- 总体取消率：{fmt_pct(oc.get('rate'))}\n")
        if "cancellation_by_hotel" in kpi and isinstance(kpi["cancellation_by_hotel"], dict):
            for hk, hv in kpi["cancellation_by_hotel"].items():
                if isinstance(hv, dict) and "rate" in hv:
                    f.write(f"  - {hk}：{fmt_pct(hv['rate'])}\n")
        if "adr_median" in kpi:
            f.write(f"- ADR 中位数：{kpi['adr_median']:.2f}\n")
        if "adr_p95" in kpi:
            f.write(f"- ADR P95：{kpi['adr_p95']:.2f}\n")
        if "adr_p99" in kpi:
            f.write(f"- ADR P99：{kpi['adr_p99']:.2f}\n")
        rc = kpi.get("room_change_rate")
        if rc and isinstance(rc, dict):
            f.write(f"- 房型变更率：{fmt_pct(rc.get('rate'))}\n")

    # ---------- 06 风险说明 ----------
    adr_thr = thr.get("adr_extreme_percentile", 99)
    with open(os.path.join(d, "06_风险说明.md"), "w", encoding="utf-8") as f:
        f.write(f"""# 风险说明

按 PBL 要求，对四类数据与统计风险逐项说明识别方法、处置策略与本期实测情况。

## 1. 数据泄漏风险

**风险描述**：`reservation_status` 字段语义上等价于「是否取消」（Canceled/No-Show/Check-Out），
若被纳入取消率预警的输入特征，会导致模型/规则在「测试时偷看答案」，得出虚高准确率。

**识别与处置**：
- 在 `REQUIRED_FIELDS` 与取消率计算输入中**显式排除** `reservation_status`
- 仅在一致性审计阶段使用（与 `is_canceled` 交叉验证）

**本期实测**：reservation_status 已从预警输入排除 → {('是' if leakage else '否（请人工核查）')}

## 2. 重复行风险

**风险描述**：hotel_bookings.csv 常因合并多源导出产生重复行，
直接删除会丢失"同一笔订单多次记录"的业务线索，且无法在后续追溯。

**识别与处置**：
- 重复行默认 `report_only`：计数 + 写入 `quality/cleaning_log.csv` 留痕
- **未经人工确认不删除**
- 重复行占比 > 20% → 触发人工复核事项

**本期实测**：
- 去重前 {dup_before:,} 行
- 去重后 {dup_after:,} 行
- 重复占比 {(1 - dup_after/dup_before)*100:.2f}%（{"已触发人工复核" if dup_before - dup_after > 0 and (1-dup_after/dup_before) > 0.2 else "未触发阈值"}）

## 3. ADR 极端值风险

**风险描述**：ADR（平均日房价）字段存在两类异常：
- `adr <= 0`：通常为系统补单或对账错误
- 极端高值（>P{adr_thr}）：可能是协议价挂错、币种错误或单笔超额订单
直接用均值会被极端值拉偏，导致收益判断失真。

**识别与处置**：
- `adr <= 0` 单独计数，占比 > 5% → 阻断收益判断
- 极端高值用 P{adr_thr} 分位数识别（本期使用 P{adr_thr}），写入 `detail-tables/adr_anomaly_list.csv`
- 主报告使用 ADR **中位数**而非均值

**本期实测**：
- ADR 中位数：{kpi.get('adr_median', 'n/a')}
- ADR P95：{kpi.get('adr_p95', 'n/a')}
- ADR P99：{kpi.get('adr_p99', 'n/a')}

## 4. 样本量不足风险

**风险描述**：5 维分组与交叉分析会产生大量小样本组合（n<30），
直接计算取消率会出现极端值（如 n=2 时取消率可能为 0% 或 100%），
若直接下结论会误导业务决策。

**识别与处置**：
- 所有比率同时输出**样本量标记**（small_sample/normal）
- 小样本组（n<30）+ 取消率 ≥ 50% → 触发人工复核，标注「不下异常结论」
- 交叉表对每个组合标注是否需要人工复核

**本期实测**：小样本高波动组合已进入人工复核清单（详见 05_示例输出/人工复核清单.md）。

## 5. 其它风险

- **口径变化风险**：本期数据无历史基线可比时，"与历史报告对比"被阻断，标注「口径变化待确认」。换多期数据后自动生效。
- **中文字体缺失风险**：matplotlib 在无中文字体的环境会输出方块字，脚本已自动探测 SimHei/YaHei/PingFang SC，若全无则降级为英文标签并警告。
- **编码探测风险**：CSV 编码可能为 utf-8/utf-8-sig/gbk/latin-1，脚本依次尝试，最差情况下用 latin-1 兜底（保证不崩，但中文可能乱码，会写入警告）。

## 6. 风险处置原则

1. **可识别即留痕**：所有风险识别后写入 `quality/data_quality.csv` 与 `cleaning_log.csv`，可追溯。
2. **高风险动作必须人工确认**：押金策略调整、房型变更、卖家/客户处罚、资源重分配等，仅给出建议并标注 `【待人工审核】`，不经人工确认不执行。
3. **小样本不下结论**：所有 n<30 的组合进入人工复核，不在主报告下因果结论。
""")

    # ---------- README（文件夹总览）----------
    with open(os.path.join(d, "README.md"), "w", encoding="utf-8") as f:
        f.write(f"""# PBL 交付物总览

本文件夹由 `hotel_watchdog_runner.py` 在巡检运行时**自动生成**，无需手工拼装。
对应 PBL 要求的 6 项交付物。

## 文件夹结构

```
PBL交付物/
├── 01_重复性工作定义.md          # 为什么需要周期性取消率与收益巡检
├── 02_Workflow流程说明.md          # 8 环节流程图 + 5 条门控 + 5 个人工接管点
├── 03_Skill文档.md                # skill 名称/适用场景/输入/输出/工具/执行步骤/停止条件/人工接管点
├── 04_工具清单.md                  # 4 类工具 + 环境要求 + 不滥用声明
├── 05_示例输出/                    # 全部为本次巡检真实产物（非编造）
│   ├── 取消率预警_五维汇总表.csv
│   ├── ADR异常清单.csv
│   ├── 资源匹配巡检表.csv
│   ├── 人工复核清单.md
│   └── 示例输出说明.md
├── 06_风险说明.md                  # 4 大风险 + 其它风险 + 处置原则
└── README.md                       # 本文件
```

## 本次巡检快照

- 数据规模：{in_rows:,} 行 × {in_cols} 列
- 巡检窗口：{win_start} ~ {win_end}（窗口内 {win_rows:,} 行）
- 总体取消率：{fmt_pct(oc.get('rate'))}
- 人工复核事项：{len(manual_review)} 项
- 阻断事项：{len(blockers)}；告警事项：{len(warnings)}

## 关联产物

- 主报告：`../hotel_watchdog_report.md`
- 摘要：`../summary.json`
- 风险表：`../risk-tables/`
- 详细表：`../detail-tables/`
- 深度诊断：`../deep-diagnosis/`
- 图表：`../charts/`

## 重新生成

```bash
python hotel_watchdog_runner.py --data-file <csv路径> --output-dir <输出目录> --dimensions all
```
默认 `--deliverables on`，每次运行都会重新生成本文件夹（覆盖旧版）。
""")


def parse_args():
    ap = argparse.ArgumentParser(description="酒店预订取消率预警与收益巡检（固化脚本）")
    ap.add_argument("--data-file", required=True, help="预订事实表 CSV 或 zip")
    ap.add_argument("--output-dir", default=None, help="输出根目录（默认数据文件旁 output/）")
    ap.add_argument("--config", default=None, help="JSON/YAML 配置文件（阈值与字段映射）")
    ap.add_argument("--start", default=None, help="窗口起始日期 YYYY-MM-DD")
    ap.add_argument("--end", default=None, help="窗口结束日期 YYYY-MM-DD（含当天）")
    ap.add_argument("--dimensions", default="all",
                    help="all|cancellation|adr|resource|cross|deep（逗号分隔可多选）")
    ap.add_argument("--cross-groups", default=None, help="指定交叉分组（逗号分隔）")
    ap.add_argument("--set", action="append", default=[], dest="set_", metavar="KEY=VALUE",
                    help="覆盖阈值，可多次使用")
    ap.add_argument("--top-n", type=int, default=10, help="风险表展示条数")
    ap.add_argument("--strict", action="store_true", help="严格模式：任何质量告警即阻断")
    ap.add_argument("--deliverables", default="on", choices=["on", "off"],
                    help="完整交付包开关")
    return ap.parse_args()


if __name__ == "__main__":
    main()
