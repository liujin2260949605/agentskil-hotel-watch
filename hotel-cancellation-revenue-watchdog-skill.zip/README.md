# hotel-cancellation-revenue-watchdog

酒店预订取消率预警与收益巡检智能体：把 `hotel_bookings.csv` 转化为可重复执行的经营巡检，产出中文主报告与按类别分文件夹的交付物。

## 安装

**项目级安装（本仓库已就位）**：skill 目录位于工作区 `.workbuddy/skills/hotel-cancellation-revenue-watchdog/`，在该项目内对话即可触发。

**用户级安装（全局可用，可选）**：将整个目录复制到 `~/.workbuddy/skills/` 下。

## 环境准备（一次性）

```bash
python -m venv <workspace>/.venv
<workspace>/.venv/Scripts/python.exe -m pip install pandas numpy matplotlib
```

## 快速开始

```bash
<venv-python> scripts/hotel_watchdog_runner.py \
  --data-file <你的 hotel_bookings.csv 路径> \
  --output-dir <输出目录，默认数据文件旁的 output/> \
  --dimensions all
```

运行结束后查看 `output/hotel_watchdog_report.md`（主报告）与 `output/summary.json`（机器可读摘要）。

## 输出结构

```text
output/
├── hotel_watchdog_report.md   # 主报告（中文）
├── summary.json
├── clean-data/       # 清洗后全量表 + 派生字段表
├── quality/           # 数据质量审计 + 清洗留痕日志
├── risk-tables/       # 各维度取消率表 + 风险表 + 交叉分析
├── detail-tables/     # ADR 异常清单 + 资源检查 + 风险组合
├── deep-diagnosis/    # 趋势对比 + 取消集中度 + 风险放大器
├── charts/            # KPI 卡片 / 条形图 / 热力图 / 箱线图
└── deliverables/      # 业务场景 / 流程说明 / 工具清单 / 管理层摘要
```

## 边界声明

本 skill 仅做分析与建议：不做实时监控，不执行处罚、下架、调价、资源重分配等业务动作；相关建议一律标记 `【待人工审核】`。`reservation_status` 作为数据泄漏字段不进入预警输入。

## 参数与配置

完整字段映射、必需字段、已知数据风险、默认阈值与命令行参数见 `references/data_dictionary.md`。
