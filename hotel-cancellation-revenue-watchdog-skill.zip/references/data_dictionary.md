# 数据字典与配置参考（hotel-cancellation-revenue-watchdog）

本文件是 SKILL.md 的数据层参考：必需字段、可选字段、已知数据风险、默认配置、命令行参数与阈值覆盖规则。固化脚本 `scripts/hotel_watchdog_runner.py` 内置了同一套默认值；本文件与脚本不一致时，以脚本 `--help` 输出为准并回报差异。

## 必需字段

以下字段缺失时阻断或强制降级运行：

| 字段 | 用途 | 缺失时的行为 |
| --- | --- | --- |
| `hotel` | 酒店类型 | 阻断核心分组分析 |
| `is_canceled` | 取消目标字段 | 阻断取消率分析 |
| `adr` | 平均每日房价 | 不可用时降级收益巡检 |
| `lead_time` | 预订提前期 | 降级提前期分析 |
| `market_segment` | 市场细分 | 降级细分分析 |
| `distribution_channel` | 销售渠道 | 降级渠道分析 |
| `deposit_type` | 押金政策 | 降级押金分析 |
| `customer_type` | 客户类型 | 降级客户分析 |
| `reserved_room_type` | 预订房型 | 降级资源匹配巡检 |
| `assigned_room_type` | 实际分配房型 | 降级资源匹配巡检 |
| `arrival_date_year` | 到店日期构造 | 阻断日期窗口与趋势分析 |
| `arrival_date_month` | 到店日期构造 | 阻断日期窗口与趋势分析 |
| `arrival_date_day_of_month` | 到店日期构造 | 阻断日期窗口与趋势分析 |

可选但预期存在的字段：`required_car_parking_spaces`、`total_of_special_requests`、`adults`、`children`、`babies`、`stays_in_weekend_nights`、`stays_in_week_nights`、`country`、`agent`、`company`、`reservation_status`、`reservation_status_date`。

## 已知数据风险（Kaggle hotel bookings 数据集）

| 风险 | 实际情况 | 必须执行的处理规则 |
| --- | --- | --- |
| 重复记录 | 多出约 31,994 条完全重复行；约 40,165 行属于重复组 | 默认仅报告。未经用户明确指示并记录影响，不得删除。 |
| `company` 缺失 | 约 94.31% 缺失 | 不作为主分析字段。如有需要可构造 `has_company`。 |
| `agent` 缺失 | 约 13.69% 缺失 | 不当作干净的连续变量分析。构造 `has_agent` 或填充 `Unknown`。 |
| `country` 缺失 | 488 行，约 0.41% | 国家维度统计时填充 `Unknown` 并披露。 |
| `children` 缺失 | 4 行 | 填充 0，并说明对 `total_guests` 的影响。 |
| ADR 异常 | 最小值 -6.38，最大值 5400，约 1,960 条 `adr <= 0`（其中 0 值约 1,959 条） | 标记 `adr <= 0` 与 `adr > P99`；同时报告均值、中位数、P95、P99。 |
| 缺少 booking_id | 无唯一订单 ID | 将重复行处理作为数据口径风险提示。 |
| 数据泄漏字段 | `reservation_status` 与取消结果高度相关 | 排除出预警输入字段，并在输出中确认已排除。 |

## 默认配置

使用配置驱动逻辑，不得在可复用的分析代码中硬编码项目专属路径。通过 `--config <路径>` 提供 YAML 时可覆盖以下默认值：

```yaml
fields:
  hotel: hotel
  is_canceled: is_canceled
  adr: adr
  lead_time: lead_time
  market_segment: market_segment
  distribution_channel: distribution_channel
  deposit_type: deposit_type
  customer_type: customer_type
  reserved_room_type: reserved_room_type
  assigned_room_type: assigned_room_type
  required_car_parking_spaces: required_car_parking_spaces
  total_of_special_requests: total_of_special_requests
  adults: adults
  children: children
  babies: babies
  stays_in_weekend_nights: stays_in_weekend_nights
  stays_in_week_nights: stays_in_week_nights
  arrival_date_year: arrival_date_year
  arrival_date_month: arrival_date_month
  arrival_date_day_of_month: arrival_date_day_of_month
  reservation_status: reservation_status
  reservation_status_date: reservation_status_date
  country: country
  agent: agent
  company: company

cleaning:
  duplicates: report_only
  country_missing: fill_unknown
  children_missing: fill_zero
  agent_company: build_presence_flags
  adr: convert_numeric_and_flag_anomalies

thresholds:
  min_sample_size: 30
  min_sample_for_risk: 100
  cancellation_rate_alert: 0.40
  cancellation_rate_critical: 0.60
  non_refund_cancel_alert: 0.90
  room_change_rate_alert: 0.15
  adr_extreme_percentile: 99
```

字段映射原则：若用户数据表头与上述名称不同，从表头推断映射（如 `是否取消` → `is_canceled`），并将推断过程记录到 `summary.json` 与主报告。

## 派生字段口径

| 字段 | 公式 |
| --- | --- |
| `arrival_date` | 由年/月/日解析出的到店日期 |
| `total_guests` | `adults + children + babies` |
| `total_stays` | `stays_in_weekend_nights + stays_in_week_nights` |
| `is_room_changed` | `reserved_room_type != assigned_room_type` |
| `has_agent` | `agent` 是否存在 |
| `has_company` | `company` 是否存在 |
| `adr_anomaly_flag` | `adr <= 0` 或 `adr > adr_p99` |
| `lead_time_bucket` | `0-7`、`8-30`、`31-90`、`91-180`、`180+` |
| `adr_bucket` | `<=0`、`0-50`、`51-100`、`101-150`、`151-200`、`200+` |

## 命令行参数

```bash
python scripts/hotel_watchdog_runner.py \
  --data-file hotel_bookings.csv \
  --output-dir output \
  --dimensions all \
  --top-n 10
```

| 参数 | 说明 |
| --- | --- |
| `--data-file <路径>` | 必填。预订事实表 CSV（或 zip，自动解压） |
| `--output-dir <路径>` | 输出根目录，默认数据文件所在目录下的 `output/` |
| `--config <路径>` | YAML 配置文件（字段映射、清洗、阈值） |
| `--start <YYYY-MM-DD>` / `--end <YYYY-MM-DD>` | 到店日期窗口，`end` 含当天 |
| `--dimensions all\|cancellation\|adr\|resource\|cross\|deep` | 选择分析维度，默认 all |
| `--cross-groups <列表>` | 指定交叉分组（逗号分隔），如 `hotel,market_segment` |
| `--set KEY=VALUE` | 覆盖阈值，可多次使用，如 `--set cancellation_rate_alert=0.35` |
| `--top-n <N>` | 风险表展示条数，默认 10 |
| `--strict` | 严格模式：任何质量告警即阻断 |
| `--deliverables on\|off` | 完整交付包开关，默认 on |

阈值覆盖记录规则：每一次覆盖都必须记录来源（命令行 / 配置文件 / 用户指示）、原值、新值与生效值，写入 `summary.json`。

## 运行环境

- Python 3.10+；依赖：pandas、numpy、matplotlib
- 中文字体：图表使用系统字体（Windows: Microsoft YaHei / SimHei；缺失时自动回退英文标签）
- 所有输出文件默认落在 `--output-dir` 指定的目录（建议 E 盘），不写入系统盘
